<?php


// Iniciar a sessão
session_start();

include('db/conexao.php');

// Verifica se o usuário está logado
if (!isset($_SESSION['email'])) {
    // Se não estiver logado, redireciona para a página de login
    header("Location: login.php");
    exit();
}

// Se o usuário estiver logado, não é mais necessário verificar se é administrador
// Basta continuar o fluxo normal

// Você pode adicionar outras verificações aqui conforme necessário

?>