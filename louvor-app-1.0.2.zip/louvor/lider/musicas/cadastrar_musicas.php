<?php
// Incluir arquivo de conexão
include('../db/conexao.php');

// Verificar se o formulário foi submetido
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Receber os dados do formulário
    $titulo = $_POST['titulo'];
    $artista = $_POST['artista'];
    $link_musica = $_POST['link_musica'];
    $link_cifra = $_POST['link_cifra'];
    $link_vs = $_POST['link_vs'];

    $sql = "INSERT INTO musicas (titulo, artista, link_musica, link_cifra, link_vs) 
            VALUES ('$titulo', '$artista', '$link_musica', '$link_cifra', '$link_vs')";
    
    if (mysqli_query($conexao, $sql)) {
        // Redirecionar para musicas.php após o cadastro bem-sucedido
        header("Location: ../musicas.php");
        exit(); // Certifique-se de parar a execução do script após o redirecionamento
    } else {
        echo "Erro ao cadastrar a música: " . mysqli_error($conexao);
    }

    // Fechar conexão com o banco de dados
    mysqli_close($conexao);
}
?>