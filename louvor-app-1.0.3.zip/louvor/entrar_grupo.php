<!DOCTYPE html>
<html lang="pt-BR">
<? 
include('includes/head.php');

?>
<body>
    <div class="container py-5">
        <h1 class="mb-4 container-title">IEADAM</h1>
    </div>

    <!-- Campo de pesquisa -->
    <div class="container main">
        <form action="#" method="GET" class="mb-4">
            <div class="input-group">
                <input type="text" class="form-control" placeholder="Pesquisar código de grupo" name="search">
                <button class="btn btn-primary" type="submit">Pesquisar</button>
            </div>
        </form>
    </div>

    <!-- Conteúdo da página -->
    <div class="container">
        <?php
        // Conecta ao banco de dados
        include('db/conexao.php');
        // Verifica a conexão
        if (mysqli_connect_errno()) {
            echo "<div class='alert alert-danger' role='alert'>Erro ao conectar ao banco de dados: " . mysqli_connect_error() . "</div>";
            exit();
        }

        // Se houver um código de grupo pesquisado
        if (isset($_GET['search'])) {
            $search = $_GET['search'];
            // Consulta SQL para obter as informações do grupo
            $sql_grupo = "SELECT * FROM grupo WHERE codigo = '$search'";
            $result_grupo = mysqli_query($conexao, $sql_grupo);

            // Verifica se o grupo foi encontrado
            if (mysqli_num_rows($result_grupo) > 0) {
                $grupo = mysqli_fetch_assoc($result_grupo);
                echo "<div class='evento-info text-center'>";
                echo "<h4>{$grupo['nome']}</h4>";
                echo "<p>{$grupo['descricao']}</p>";
                echo "<button class='btn btn-primary' data-toggle='modal' data-target='#exampleModal'>Entrar</button>";
                echo "</div>";

                // Modal
                echo "<div class='modal fade' id='exampleModal' tabindex='-1' role='dialog' aria-labelledby='exampleModalLabel' aria-hidden='true'>";
                echo "<div class='modal-dialog' role='document'>";
                echo "<div class='modal-content'>";
                echo "<div class='modal-header'>";
                echo "<h5 class='modal-title' id='exampleModalLabel'>{$grupo['nome']}</h5>";
                echo "<button type='button' class='close' data-dismiss='modal' aria-label='Close'>";
                echo "<span aria-hidden='true'>&times;</span>";
                echo "</button>";
                echo "</div>";
                echo "<div class='modal-body'>";
                echo "<p>{$grupo['descricao']}</p>";
                echo "</div>";
                echo "<div class='modal-footer'>";
                echo "<button type='button' class='btn btn-secondary' data-dismiss='modal'>Fechar</button>";
                echo "</div>";
                echo "</div>";
                echo "</div>";
                echo "</div>";
            } else {
                echo "<div class='alert alert-danger' role='alert'>Grupo não encontrado.</div>";
            }
        }
        ?>
    </div>

    <!-- Bootstrap JS e jQuery (opcional) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <script>
        // Script omitido para brevidade
    </script>
    <?php include('menu.php'); ?>
</body>

</html>