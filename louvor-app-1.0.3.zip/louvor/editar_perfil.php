<?php
session_start();

// Verifica se o usuário está logado
if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}

// Inclui o arquivo de conexão com o banco de dados
include('db/conexao.php');

// Recupera o email do usuário da sessão
$email = $_SESSION['email'];

// Recupera os dados do usuário
$sql_select = "SELECT * FROM usuarios WHERE email = '$email'";
$result_select = mysqli_query($conexao, $sql_select);
$row = mysqli_fetch_assoc($result_select);

// Recebe os dados do formulário
$novoNome = $_POST['novoNome'];
$novaSenha = $_POST['novaSenha'];
$novaDataNascimento = $_POST['novaDataNascimento'];

// Verifica se uma nova foto foi enviada
if ($_FILES['novaFoto']['name']) {
    // Se uma nova foto foi enviada, trata como antes
    $novaFoto = $_FILES['novaFoto']['name'];
    $tempName = $_FILES['novaFoto']['tmp_name'];
    $fotoDir = "../uploads/"; // Diretório para salvar as fotos

    // Verifica se o diretório de uploads existe e cria se não existir
    if (!file_exists($fotoDir)) {
        mkdir($fotoDir, 0777, true);
    }

    $targetFile = $fotoDir . basename($novaFoto);

    // Move a foto para o diretório de uploads
    if (move_uploaded_file($tempName, $targetFile)) {
        // Foto movida com sucesso
    } else {
        // Se houver um erro ao mover a foto, exibe uma mensagem de erro
        echo "Erro ao mover a foto.";
        exit();
    }
} else {
    // Se nenhum arquivo foi enviado, verifica se há uma imagem existente no banco de dados
    if (!empty($row['foto'])) {
        // Se houver uma imagem existente, mantém a mesma
        $novaFoto = $row['foto'];
    } else {
        // Se não houver imagem existente, exibe uma mensagem de erro
        header("Location: perfil.php");
        exit();
    }
}

// Atualiza as informações do usuário no banco de dados
$sql = "UPDATE usuarios SET nome = '$novoNome', senha = '$novaSenha', foto = '$novaFoto', aniversario = '$novaDataNascimento' WHERE email = '$email'";
$result = mysqli_query($conexao, $sql);

// Verifica se a atualização foi bem-sucedida
if ($result) {
    // Redireciona de volta para a página do perfil com uma mensagem de sucesso
    header("Location: perfil.php?success=1");
    exit();
} else {
    // Se houver um erro na atualização, redireciona com uma mensagem de erro
    header("Location: perfil.php?error=1");
    exit();
}

// Fecha a conexão com o banco de dados
mysqli_close($conexao);
?>