<?php
include('verify.php');

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['criar'])) {
    // Recuperar os dados do formulário
    $nome_grupo = $_POST['nome_grupo'];
    $codigo_grupo = $_POST['codigo_grupo'];
    $foto_grupo = $_POST['foto_grupo'];

    // Inserir o novo grupo no banco de dados
    $sql = "INSERT INTO grupos (nome_grupo, codigo_grupo, nivel_id, foto_grupo) VALUES ('$nome_grupo', '$codigo_grupo', '$usuario_id', '$foto_grupo')";
    if (mysqli_query($conexao, $sql)) {
        echo "Grupo criado com sucesso!";
    } else {
        echo "Erro ao criar grupo. Por favor, tente novamente.";
    }
}

// Formulário para criar um novo grupo
echo "<form method='POST' action='<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>'>";
echo "<input type='text' name='nome_grupo' placeholder='Nome do grupo'><br>";
echo "<input type='text' name='codigo_grupo' placeholder='Código do grupo'><br>";
echo "<input type='text' name='foto_grupo' placeholder='URL da foto do grupo'><br>";
echo "<input type='submit' name='criar' value='Criar Grupo'>";
echo "</form>";

// Fechar a conexão com o banco de dados
mysqli_close($conexao);
?>