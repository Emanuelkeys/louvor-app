<?php
// Configurações do banco de dados
$hostname = '127.0.0.1'; // Endereço do servidor MySQL
$username = 'root'; // Nome de usuário do banco de dados
$password = 'root'; // Senha do banco de dados
$database = 'louvor'; // Nome do banco de dados

// Criar conexão
$conexao = mysqli_connect($hostname, $username, $password, $database);

// Verificar conexão
if (!$conexao) {
    die("Erro ao conectar ao banco de dados: " . mysqli_connect_error());
}
?>