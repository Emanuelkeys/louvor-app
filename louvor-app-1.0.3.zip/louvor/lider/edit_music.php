<?php
// Incluir arquivo de conexão
include('../db/conexao.php');

// Verificar se o ID foi fornecido como parâmetro
if(isset($_GET['id'])){
    $id = $_GET['id'];

    // Consulta para obter os dados da música com o ID fornecido
    $query = "SELECT * FROM musicas WHERE id = $id";
    $result = mysqli_query($conexao, $query);

    // Verificar se a consulta retornou resultados
    if(mysqli_num_rows($result) > 0){
        $musica = mysqli_fetch_assoc($result);

        // Preencher os campos do formulário com os dados da música
        $titulo = $musica['titulo'];
        $artista = $musica['artista'];
        $link_musica = $musica['link_musica'];
        $link_cifra = $musica['link_cifra'];
        $link_vs = $musica['link_vs'];
    } else{
        echo "Música não encontrada";
    }
}

// Fechar conexão com o banco de dados
mysqli_close($conexao);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Editar Música</title>
    <!-- Adicionar o CSS do Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome (ícones) -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <!-- CSS personalizado -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/musica.css" rel="stylesheet">
</head>
<body>
<?include('head.php')?>
<div class="container d-flex justify-content-center align-items-center" style="height: 100vh;">
    <form id="meuFormulario" class="p-4 border rounded shadow-sm" style="width: 300px;" method="POST" action="editar_musica.php">
        <h2 class="mb-4 text-center">Editar Música</h2>
        <!-- Adicione um input hidden para armazenar o ID da música -->
        <input type="hidden" name="id" value="<?php echo $id; ?>">
        
        <div class="mb-3">
            <label for="titulo" class="form-label">Título:</label>
            <input type="text" id="titulo" name="titulo" class="form-control" value="<?php echo $titulo; ?>">
        </div>
        <div class="mb-3">
            <label for="artista" class="form-label">Artista:</label>
            <input type="text" id="artista" name="artista" class="form-control" value="<?php echo $artista; ?>">
        </div>
        <div class="mb-3">
            <label for="link_musica" class="form-label">Link da Música:</label>
            <input type="text" id="link_musica" name="link_musica" class="form-control" value="<?php echo $link_musica; ?>">
        </div>
        <div class="mb-3">
            <label for="link_cifra" class="form-label">Link da Cifra:</label>
            <input type="text" id="link_cifra" name="link_cifra" class="form-control" value="<?php echo $link_cifra; ?>">
        </div>
        <div class="mb-3">
            <label for="link_vs" class="form-label">Link do VS:</label>
            <input type="text" id="link_vs" name="link_vs" class="form-control" value="<?php echo $link_vs; ?>">
        </div>
        <button type="submit" class="btn btn-primary w-100">Salvar</button>
    </form>
</div>
<?php include('menu.php'); ?>
<script>
    document.getElementById('meuFormulario').addEventListener('submit', function(event) {
        // Validar os campos do formulário aqui
        // Se os campos estiverem corretos, envie para "editar_musica.php" via submit do formulário
    });
</script>

<!-- Adicionar o JavaScript do Bootstrap 5 (opcional) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>