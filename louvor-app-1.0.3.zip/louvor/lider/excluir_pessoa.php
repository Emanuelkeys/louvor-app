<?php
// Verifica se o ID da escala foi passado via GET
if(isset($_GET['id_escala'])) {
    // Conecta ao banco de dados
    include('../db/conexao.php');

    // Verifica a conexão
    if (mysqli_connect_errno()) {
        echo "Erro ao conectar ao banco de dados: " . mysqli_connect_error();
        exit();
    }

    // Obtém o ID da escala da URL
    $id_escala = $_GET['id_escala'];

    // Query SQL para excluir a pessoa da escala
    $sql_excluir = "DELETE FROM escala WHERE id_escala = $id_escala";

    // Executa a consulta
    if(mysqli_query($conexao, $sql_excluir)) {
        // Pessoa excluída com sucesso, redireciona de volta para a página anterior
        header("Location: {$_SERVER['HTTP_REFERER']}");
        exit();
    } else {
        echo "Erro ao excluir a pessoa da escala: " . mysqli_error($conexao);
    }

    // Fecha a conexão com o banco de dados
    mysqli_close($conexao);
} else {
    echo "ID da escala não especificado.";
}
?>