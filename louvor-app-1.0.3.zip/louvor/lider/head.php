<div class="container py-5">
        <h1 class="mb-4">WorshipFlow</h1>
  </div>
  <style>
    .container {
      text-align:;
        margin-top: 0px;
        max-height: 575px; /* Altura máxima da div principal */
    overflow-y: auto; /* Adiciona rolagem vertical */
    max-width: 500px; /* Largura máxima desejada */
    margin-left: auto; /* Centraliza horizontalmente */
    margin-right: auto; /* Centraliza horizontalmente */
}
  </style>