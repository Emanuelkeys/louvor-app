<?php
// Incluir arquivo de conexão
include('../db/conexao.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $titulo = $_POST['titulo'];
    $artista = $_POST['artista'];
    $link_musica = $_POST['link_musica'];
    $link_cifra = $_POST['link_cifra'];
    $link_vs = $_POST['link_vs'];

    // Consulta SQL para atualizar os dados da música no banco
    $query_update = "UPDATE musicas SET titulo='$titulo', artista='$artista', link_musica='$link_musica', link_cifra='$link_cifra', link_vs='$link_vs' WHERE id=$id";

    // Executar a consulta de atualização
    $result_update = mysqli_query($conexao, $query_update);

    if ($result_update) {
        // Redirecionar para a página de listagem de músicas após a atualização
        header("Location: musicas.php");
        exit();
    } else {
        echo "Erro ao atualizar a música. Por favor, tente novamente.";
    }
}

// Fechar conexão com o banco de dados
mysqli_close($conexao);
?>