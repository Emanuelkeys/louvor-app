<?php
session_start();

// Verifica se a variável de sessão 'email' está definida
if (!isset($_SESSION['email'])) {
    // Se não estiver definida, redireciona o usuário para a página de login
    header("Location: ../login.php");
    exit();
}

// Verifica se o ID da música a ser excluída foi enviado via GET
if (isset($_GET['delete_id'])) {
    // Conecta-se ao banco de dados
    include('db/conexao.php');

    // Obtém e sanitiza o ID da música a ser excluída
    $delete_id = mysqli_real_escape_string($conexao, $_GET['delete_id']);

    // Cria a consulta para excluir a música
    $sql = "DELETE FROM musicas WHERE id = $delete_id";

    // Executa a consulta
    if (mysqli_query($conexao, $sql)) {
        // Redireciona de volta para esta página após a exclusão
        header("Location: {$_SERVER['PHP_SELF']}");
        exit();
    } else {
        echo "Erro ao excluir música: " . mysqli_error($conexao);
    }

    // Fecha a conexão com o banco de dados
    mysqli_close($conexao);
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LOUVOR</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome (ícones) -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <!-- CSS personalizado -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/musica.css" rel="stylesheet">
    <style>
      .add-music-button {
    position: fixed;
    bottom: 48px; /* Diminui a distância inferior em 20% */
    right: 16px; /* Diminui a distância direita em 20% */
    width: 40px; /* Diminui a largura em 20% */
    height: 40px; /* Diminui a altura em 20% */
    background-color: #007bff;
    color: #fff;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    box-shadow: 0px 1.6px 4px rgba(0, 0, 0, 0.16); /* Diminui a sombra em 20% */
}

.add-music-button:hover {
    background-color: #0056b3;
}

.music-details {
    display: none;
}

.container.top-fixed {
    position: fixed;
    top: 0px; /* Diminui a posição superior em 20% */
    left: 50%;
    transform: translateX(-50%);
    background-color: white;
    padding: 4px; /* Diminui o espaçamento interno em 20% */
    border: 0.8px solid #ccc; /* Diminui a largura da borda em 20% */
    z-index: 999;
    text-align: center;
}

.container.main {
    margin-top: 25%; /* Diminui o espaçamento superior em 20% */
    max-height: 625px; /* Define a altura máxima como 80% da altura da tela */
    overflow-y: auto;
    max-width: 400px; /* Diminui a largura máxima em 20% */
    margin-left: 6%; /* Diminui a margem esquerda em 20% */
    margin-right: auto; /* Centraliza horizontalmente */
}

.music-gallery {
    margin-bottom: 16px; /* Diminui a margem inferior em 20% */
}

.music-item {
    /* Adicione estilos para os itens da galeria de música conforme necessário */
}
/* Estilos personalizados para o menu */
        .menu {
            /* Adicione seus estilos para o menu aqui */
            background-color: #333;
            color: #fff;
            padding: 10px;
        }
        .menu a {
            color: #fff;
            text-decoration: none;
            margin-right: 10px;
        }
        .menu a:hover {
            text-decoration: underline;
        }
        
        /* Estilo para o modal */
.modal-dialog {
    max-width: 80%;
    margin: auto; /* Centralizar o modal */
}

.modal-content {
    border-radius: 10px;
}

.modal-header {
    border-bottom: none;
    padding-top: 20px;
    padding-bottom: 20px;
}

.modal-title {
    font-size: 1.5rem;
    font-weight: bold;
    text-align: center;
    margin-bottom: 0;
}

.modal-body {
    padding: 20px;
    text-align: left;
}

.modal-footer {
    border-top: none;
}

/* Estilo para os links das músicas */
.music-link {
    display: block;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    background-color: #f2f2f2; /* Fundo dos links */
    padding: 5px 10px; /* Espaçamento interno */
    border-radius: 5px; /* Borda arredondada */
    box-shadow: 0 0 5px rgba(0, 0, 0, 0.2); /* Sombra 3D */
    text-decoration: none; /* Remover sublinhado */
    color: #333; /* Cor do texto */
}

.highlight-person, .highlight-music {
    background-color: #f8f9fa; /* Cor de fundo clean */
    padding: 5px; /* Espaçamento interno para melhorar a aparência */
    border-radius: 5px; /* Arredondamento das bordas */
    color: #333; /* Cor do texto */
}

.highlight-person {
    font-weight: bold; /* Destacar o nome da pessoa */
}

.highlight-music {
    opacity: 0.7; /* Opacidade reduzida para o nome da música */
}

/* Estilo para alinhar o texto à esquerda */
.name-container {
    display: flex;
    align-items: baseline; /* Alinha os elementos pela base */
}

.name-container span {
    margin-left: 10px; /* Margem à esquerda para separar os nomes */
}

/* Estilo para o botão de exclusão no canto inferior direito da tela */
.btn-fixed-bottom-right {
    position: fixed;
    bottom: 60px;
    right: 20px;
    z-index: 999; /* Certifica-se de que o botão esteja acima de outros elementos */
}
#btn-editar {
    position: fixed;
    right: 100%; /* Distância da direita */
    top: 10px; /* Distância do topo */
}
    </style>
</head>

<body>
<div class="container top-fixed">
    <h1 class="mb-4">WorshipFlow</h1>
    <div class="input-group mb-3">
        <input type="text" class="form-control" id="searchInput" placeholder="Pesquisar música ou artista" aria-label="Pesquisar música ou artista" aria-describedby="button-addon2">
        <button class="btn btn-outline-secondary" type="button" id="button-addon2"><i class="fas fa-search"></i></button><br>
    </div>
</div>
<!-- Conteúdo específico da página de músicas -->
<div class="container main">
    <!-- Campo de pesquisa -->
    

    <!-- Galeria de músicas -->
    <div class="music-gallery">
        <!-- Aqui você pode iterar sobre as músicas e exibir cada uma delas como um item da galeria -->
        <?php
        // Incluir arquivo de conexão
        include('db/conexao.php');

        // Consulta SQL para selecionar as músicas
        $sql = "SELECT * FROM musicas";
        $resultado = mysqli_query($conexao, $sql);

        // Verifica se há músicas
        if (mysqli_num_rows($resultado) > 0) {
            // Loop através dos resultados
            while ($row = mysqli_fetch_assoc($resultado)) {
    echo "<div class='music-item' data-toggle='modal' data-target='#musicDetailsModal'";
    echo "data-title='" . $row['titulo'] . "' data-artist='" . $row['artista'] . "' data-link='" . $row['link_musica'] . "' data-cifra='" . $row['link_cifra'] . "' data-vs='" . $row['link_vs'] . "'>";
    echo "<i class='fas fa-music'></i>";
    echo "<p class='title'>" . $row['titulo'] . "</p>";
    echo "<p class='artist'>" . $row['artista'] . "</p>";
    echo "<a href='?delete_id=" . $row['id'] . "' class='btn btn-danger'>Excluir</a>";
    
    // Botão de editar
    echo "<a id='bnt-editar' href='edit_music.php?id=" . $row['id'] . "' class='btn btn-primary'>Editar</a>";

    echo "</div>";
}
        } else {
            echo "Nenhuma música Cadastrada";
        }

        // Fechar conexão com o banco de dados
        mysqli_close($conexao);
        ?>
    </div>
</div>

<!-- Modal de detalhes da música -->
<div class="modal fade" id="musicDetailsModal" tabindex="-1" aria-labelledby="musicDetailsModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content rounded-3">
            <div class="modal-header bg-primary text-white border-0">
                <h5 class="modal-title" id="musicDetailsModalLabel"><i class="fas fa-music me-2"></i>Detalhes da Música</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="mb-4">
                    <h3 id="musicTitle" class="fw-bold mb-2">Título da Música</h3>
                    <p id="musicArtist" class="text-muted fs-6 mb-3"><i class="fas fa-user me-1"></i>Artista</p>
                </div>
                <div id="musicLink" class="mb-4">
                    <h6 class="mb-2">Link da Música</h6>
                    <a href="#" class="btn btn-outline-primary btn-sm rounded-pill">Abrir Link</a>
                </div>
                <div id="musicCifra" class="mb-4">
                    <h6 class="mb-2">Link da Cifra</h6>
                    <a href="#" class="btn btn-outline-primary btn-sm rounded-pill">Abrir Cifra</a>
                </div>
                <div id="musicVS" class="mb-4">
                    <h6 class="mb-2">Versão Solo</h6>
                    <a href="#" class="btn btn-outline-primary btn-sm rounded-pill">Abrir VS</a>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary btn-sm rounded-pill" data-bs-dismiss="modal">Fechar</button>
            </div>
        </div>
    </div>
</div>

<!-- Botão para adicionar música -->
<div class="add-music-button" id="addMusicButton">
    <i class="fas fa-music"></i>
</div>

<!-- Modal de adição de música -->
<div class="modal fade" id="addMusicModal" tabindex="-1" aria-labelledby="addMusicModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addMusicModalLabel">Adicionar Música</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="addMusicForm">
                <!-- Formulário de adição de música -->
                <form action="musicas/cadastrar_musicas.php" method="post">
                    <div class="mb-3">
                        <label for="tituloInput" class="form-label visually-hidden">Título</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-music"></i></span>
                            <input type="text" class="form-control" id="tituloInput" name="titulo" placeholder="Título da música">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="artistaInput" class="form-label visually-hidden">Artista</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-user"></i></span>
                            <input type="text" class="form-control" id="artistaInput" name="artista" placeholder="Artista da música">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="linkMusicaInput" class="form-label visually-hidden">Link da música</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-music"></i></span>
                            <input type="text" class="form-control" id="linkMusicaInput" name="link_musica" placeholder="Link da música">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="linkCifraInput" class="form-label visually-hidden">Link da cifra</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="far fa-file-pdf"></i></span>
                            <input type="text" class="form-control" id="linkCifraInput" name="link_cifra" placeholder="Link da cifra">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="linkVSInput" class="form-label visually-hidden">Link do VS</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-headphones-alt"></i></span>
                            <input type="text" class="form-control" id="linkVSInput" name="link_vs" placeholder="Link do VS">
                        </div>
                    </div>
                    <!-- Adicione os outros campos conforme necessário -->
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                        <button type="submit" class="btn btn-primary">Salvar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    // Adiciona um evento de clique ao botão "Adicionar Música"
    document.getElementById('addMusicButton').addEventListener('click', function() {
        // Seleciona o modal de adição de música
        var addMusicModal = new bootstrap.Modal(document.getElementById('addMusicModal'));
        // Exibe o modal
        addMusicModal.show();
    });

    // Adiciona um evento de clique aos itens de música para exibir os detalhes
    var musicItems = document.querySelectorAll('.music-item');
    musicItems.forEach(function(item) {
        item.addEventListener('click', function() {
            var title = this.getAttribute('data-title');
            var artist = this.getAttribute('data-artist');
            var link = this.getAttribute('data-link');
            var cifra = this.getAttribute('data-cifra');
            var vs = this.getAttribute('data-vs');
            document.getElementById('musicTitle').textContent = title;
            document.getElementById('musicArtist').textContent = artist;
            document.getElementById('musicLink').innerHTML = "<a href='" + link + "' class='btn btn-primary'><i class='fas fa-music'></i> Link da música</a>";
            document.getElementById('musicCifra').innerHTML = "<a href='" + cifra + "' class='btn btn-primary'><i class='far fa-file-pdf'></i> Link da cifra</a>";
            document.getElementById('musicVS').innerHTML = "<a href='" + vs + "' class='btn btn-primary'><i class='fas fa-headphones-alt'></i> VS</a>";
            var musicDetailsModal = new bootstrap.Modal(document.getElementById('musicDetailsModal'));
            musicDetailsModal.show();
        });
    });

    // Adiciona funcionalidade de busca
    document.getElementById('button-addon2').addEventListener('click', function() {
        var searchTerm = document.getElementById('searchInput').value.toLowerCase();
        var musicItems = document.querySelectorAll('.music-item');
        musicItems.forEach(function(item) {
            var title = item.getAttribute('data-title').toLowerCase();
            var artist = item.getAttribute('data-artist').toLowerCase();
            if (title.includes(searchTerm) || artist.includes(searchTerm)) {
                item.style.display = 'block';
            } else {
                item.style.display = 'none';
            }
        });
    });
</script>
<?php include('menu.php'); ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>