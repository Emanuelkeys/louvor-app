<?php
session_start();

// Verifica se a variável de sessão 'email' não está definida
if (!isset($_SESSION['email'])) {
    // Se não estiver definida, redireciona o usuário para a página de login
    header("Location: login.php");
    exit();
}

include('db/conexao.php');

// Criar conexão
$conexao = mysqli_connect($hostname, $username, $password, $database);

// Verificar conexão
if (!$conexao) {
    die("Erro ao conectar ao banco de dados: " . mysqli_connect_error());
}

// Consulta SQL para obter as agendas cadastradas
$sql_agendas = "SELECT id, titulo, data_evento FROM eventos";
$result_agendas = $conexao->query($sql_agendas);

// Array para armazenar as agendas
$agendas = array();
if ($result_agendas->num_rows > 0) {
    while ($row = $result_agendas->fetch_assoc()) {
        // Adiciona a agenda ao array
        $agendas[$row["id"]] = array(
            "titulo" => $row["titulo"],
            "data_evento" => $row["data_evento"]
        );
    }
}

// Consulta SQL para obter as músicas cadastradas
$sql_musicas = "SELECT id, titulo FROM musicas";
$result_musicas = $conexao->query($sql_musicas);

// Array para armazenar as músicas
$musicas = array();
if ($result_musicas->num_rows > 0) {
    while ($row = $result_musicas->fetch_assoc()) {
        // Adiciona a música ao array
        $musicas[$row["id"]] = $row["titulo"];
    }
}

// Consulta SQL para obter os usuários cadastrados
$sql_usuarios = "SELECT id, nome, funcao FROM usuarios";
$result_usuarios = $conexao->query($sql_usuarios);

// Array para armazenar os nomes e funções dos usuários
$usuarios = array();
if ($result_usuarios->num_rows > 0) {
    while ($row = $result_usuarios->fetch_assoc()) {
        // Adiciona o usuário ao array
        $usuarios[$row["id"]] = array(
            "nome" => $row["nome"],
            "funcao" => $row["funcao"]
        );
    }
}
// Verifica se a música foi selecionada
if (!isset($_POST['musicas']) || empty($_POST['musicas'])) {
    // Se não houver música selecionada, obtém a função da pessoa selecionada
    $id_pessoa = $_POST['nomes_pessoa'];
    $funcao_pessoa = $usuarios[$id_pessoa]['funcao'];
    // Usa a função da pessoa como o nome da música
    $nome_musica = $funcao_pessoa;
} else {
    // Se houver música selecionada, obtém o nome da música a partir do array $musicas usando o ID da música selecionada
    $nome_musica = $musicas[$_POST['musicas']];
}

// Agora você pode usar $nome_musica ao inserir os dados na tabela de escala
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WorshipFlow</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome (ícones) -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    
    <!-- CSS personalizado -->
    <style>
        /* Estilos para toda a estrutura */
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            color: #333;
        }

        .container {
            max-width: 400px;
            margin: 50px auto; /* Centraliza verticalmente */
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            margin-bottom: 20px;
            text-align: center;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-label {
            display: flex;
            align-items: center;
            margin-bottom: 5px;
        }

        .form-label i {
            margin-right: 10px;
        }

        .form-control {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            transition: border-color 0.3s ease;
        }

        .form-control:focus {
            border-color: #007bff;
            outline: none;
        }

        .btn-primary {
            display: block;
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 5px;
            background-color: #007bff;
            color: #fff;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .btn-primary:hover {
            background-color: #0056b3;
        }

        /* Posicionamento da lupa junto à seleção de músicas */
        .custom-select {
            position: relative;
        }

        .custom-select::after {
            content: '\f002'; /* código da lupa do Font Awesome */
            font-family: 'Font Awesome\ 5 Free';
            position: absolute;
            top: 50%;
            right: 10px;
            transform: translateY(-50%);
            color: #007bff; /* Cor azul para a lupa */
            pointer-events: none; /* Evita que a lupa interfira com a seleção */
        }

        /* Estilo para ocultar a pesquisa por título ou artista */
        .search-input {
            display: none;
        }
        .infor{
          background-color: orange;
          border-radius: 5px;
          padding: 10px;
          margin: 50px;
          text-align: center;
        }
        .custom-select-container {
    max-height: 600px; /* Define a altura máxima */
    overflow-y: auto; /* Ativa a rolagem automática quando a altura máxima é atingida */
}
.custom-select-scrollable {
    max-height: 600px; /* Define a altura máxima */
    overflow-y: auto; /* Ativa a rolagem automática quando a altura máxima é atingida */
}
.custom-select-scrollable {
    max-height: 600px; /* Define a altura máxima */
    overflow-y: auto; /* Ativa a rolagem automática quando a altura máxima é atingida */
}
    
    .mensagem {
    background-color: GhostWhite; /* Fundo verde claro */
    color: black; /* Cor do texto branca */
    font-family: Arial, sans-serif;
    text-align: center;
    padding: 5px;
    border-radius: 3px;
}

</style>
    
</head>
<body>
  <div class="container">
      <?include('head.php')?>
<h5 id="mensagem" class="mensagem"></h5>

<script>
if (window.location.href.indexOf("escala.php?=sucesso") !== -1) {
    document.getElementById("mensagem").innerHTML = "Escalado!";
    setTimeout(function() {
        window.location.href="escala.php"; // Recarregar a página após 5 segundos
    }, 5000); // 5000 milissegundos = 5 segundos
}
</script>
        <!-- Formulário de cadastro de escala -->
        <form method="post" action="processar_cadastro_escala.php">
    <div class="form-group">
        <label for="id_evento" class="form-label"><i class="far fa-calendar-alt"></i><br></label>
        <select class="form-select custom-select custom-select-container" id="id_evento" name="id_evento" required>
            <option value="" disabled>Selecione o evento</option>
            <?php
            // Variável para armazenar a data atual
            $data_atual = date('d-m-Y'); // Alterado o formato para D-M-A
            
            // Variável para armazenar o ID do evento mais próximo
            $evento_mais_proximo_id = null;
            
            // Variável para armazenar a diferença mínima entre a data atual e a data do evento
            $diferenca_minima = PHP_INT_MAX;
            
            // Loop para exibir as opções de evento
            foreach ($agendas as $id => $agenda) {
                // Calcula a diferença entre a data atual e a data do evento
                $diferenca = strtotime($agenda['data_evento']) - strtotime($data_atual);
                
                // Verifica se a diferença é menor que a diferença mínima atual
                if ($diferenca >= 0 && $diferenca < $diferenca_minima) {
                    // Atualiza o ID do evento mais próximo e a diferença mínima
                    $evento_mais_proximo_id = $id;
                    $diferenca_minima = $diferenca;
                }
                
                // Exibe a opção do evento
                // Alterado o formato da data para D-M-A
                echo "<option value='$id' " . ($evento_mais_proximo_id == $id ? 'selected' : '') . ">{$agenda['titulo']} - " . date('d-m-Y', strtotime($agenda['data_evento'])) . "</option>";
            }
            ?>
        </select>
    </div>
    <div class="form-group">
    <label for="musicas" class="form-label"><i class="fas fa-music"></i><br></label>
    <select class="form-select custom-select custom-select-scrollable mt-2" id="musicas" name="musicas">
        <option value="" selected disabled>Selecione a música</option>
        <option value="search">Pesquisar música</option>
        <?php
        // Loop para exibir as opções de música
        foreach ($musicas as $id => $musica) {
            echo "<option value='$id'>$musica</option>";
        }
        ?>
        
    </select>
    <div class="form-group search-input mt-2">
        <label for="searchMusic" class="form-label"><i class="fas fa-search"></i><br></label>
        <input type="text" class="form-control" id="searchMusic" name="searchMusic" placeholder="Pesquisar título ou artista" autofocus>
    </div>
</div>
<div class="form-group">
    <label for="nomes_pessoa" class="form-label"><i class="fas fa-users"></i><br></label>
    <select class="form-select custom-select custom-select-scrollable mt-2" id="nomes_pessoa" name="nomes_pessoa" required>
        <option value="" selected disabled>Selecione a pessoa</option>
        <?php
// Cria um array para armazenar as opções de pessoa
$options = array();

// Loop para adicionar as opções de pessoa ao array
foreach ($usuarios as $id => $usuario) {
    // Verifica se a função é "voz" e adiciona ao início do array
    if ($usuario['funcao'] == 'voz') {
        array_unshift($options, "<option value='$id'>{$usuario['nome']} - {$usuario['funcao']}</option>");
    } else {
        // Adiciona as demais funções em ordem alfabética ao array
        $options[] = "<option value='$id'>{$usuario['nome']} - {$usuario['funcao']}</option>";
    }
}

// Exibe as opções de pessoa
echo implode('', $options);
?>
    </select>
</div>
    <button type="submit" class="btn btn-primary"><i class="fas fa-check"></i> Cadastrar Escala</button>
</form>
    </div>
    <div class='alert alert-warning text-center' role='alert'>
    <p>SELECIONE UMA PESSOA POR VEZ</p>
</div>

    <!-- JavaScript para controlar a abertura/fechamento da pesquisa e lupa -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const musicasSelect = document.getElementById('musicas');
            const searchInput = document.getElementById('searchMusic');
            const musicasOptions = document.querySelectorAll('#musicas option:not([value="search"])');

            // Função para filtrar as opções de músicas com base no texto de pesquisa
            function filterMusicOptions(searchText) {
                const search = searchText.toLowerCase();
                musicasOptions.forEach(option => {
                    const text = option.textContent.toLowerCase();
                    if (text.includes(search)) {
                        option.style.display = 'block';
                    } else {
                        option.style.display = 'none';
                    }
                });
            }

            musicasSelect.addEventListener('change', function() {
                if (this.value === 'search') {
                    searchInput.parentElement.style.display = 'block';
                    searchInput.focus(); // Foca automaticamente no campo de pesquisa
                } else {
                    searchInput.parentElement.style.display = 'none';
                    musicasOptions.forEach(option => {
                        option.style.display = 'block'; // Mostra todas as opções quando não estiver pesquisando
                    });
                }
            });

            searchInput.addEventListener('input', function() {
                filterMusicOptions(this.value);
            });
        });
    </script>
    <?php include('menu.php'); ?>
</body>
</html>