<?php
// Verifica se o ID do usuário foi recebido
if (isset($_POST['id'])) {
    // Inclui o arquivo de conexão com o banco de dados
    include('db/conexao.php');

    // Obtém o ID do usuário
    $idUsuario = $_POST['id'];

    // Prepara a consulta SQL para excluir o usuário
    $sql = "DELETE FROM usuarios WHERE id = ?";

    // Prepara a instrução SQL usando o método prepare
    $stmt = mysqli_prepare($conexao, $sql);

    // Verifica se a preparação da consulta foi bem-sucedida
    if ($stmt) {
        // Associa o parâmetro à instrução SQL
        mysqli_stmt_bind_param($stmt, "i", $idUsuario);

        // Executa a consulta
        if (mysqli_stmt_execute($stmt)) {
            // Retorna um código de sucesso
            echo "success";
        } else {
            // Retorna uma mensagem de erro
            echo "Erro ao apagar usuário";
        }

        // Fecha a instrução
        mysqli_stmt_close($stmt);
    } else {
        // Retorna uma mensagem de erro
        echo "Erro na preparação da consulta";
    }

    // Fecha a conexão com o banco de dados
    mysqli_close($conexao);
} else {
    // Retorna uma mensagem de erro se o ID do usuário não foi recebido
    echo "ID do usuário não recebido";
}
?>