<?
session_start();

// Verifica se a variável de sessão 'email' não está definida
if (!isset($_SESSION['email'])) {
    // Se não estiver definida, redireciona o usuário para a página de login
    header("Location: ../login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LOUVOR - Membros</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome (ícones) -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <!-- CSS personalizado -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/membro.css" rel="stylesheet">
    <style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f8f9fa;
    }

    .container {
        margin-top: 0px;
        max-height: 575px; /* Altura máxima da div principal */
    overflow-y: auto; /* Adiciona rolagem vertical */
    max-width: 500px; /* Largura máxima desejada */
    margin-left: auto; /* Centraliza horizontalmente */
    margin-right: auto; /* Centraliza horizontalmente */
}

    h1 {
        color: #007bff;
        text-align: center;
    }

    .lista-membros {
        list-style: none;
        padding: 0;
    }

    .membro {
        display: flex;
        align-items: center;
        padding: 10px;
        background-color: #fff;
        border-radius: 8px;
        margin-bottom: 10px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }

    .membro .foto-membro {
        margin-right: 10px;
    }

    .membro .info-membro {
        flex-grow: 1;
    }

    .nome-membro {
        font-weight: bold;
    }

    .acoes-membro {
        margin-left: auto;
    }

    .acoes-membro button {
        margin-left: 5px;
    }

    .add-user-button {
        color: #fff;
        background-color: #28a745;
        border: none;
    }

    .add-user-button:hover {
        background-color: #218838;
    }

    .modal-content {
        background-color: #fff;
        border-radius: 10px;
    }

    .modal-title {
        color: #007bff;
    }

    .btn-primary {
        background-color: #007bff;
        border: none;
    }

    .btn-primary:hover {
        background-color: #0056b3;
    }
        .add-user-button {
        position: fixed;
        bottom: 60px;
        right: 20px;
        z-index: 1000;
        border-radius: 50%; /* Torna o botão redondo */
        width: 50px; /* Define a largura */
        height: 50px; /* Define a altura */
        text-align: center; /* Alinha o ícone verticalmente */
        line-height: 40px; /* Centraliza o ícone horizontalmente */
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); /* Adiciona sombra ao botão */
    }
      .foto-membro {
    position: relative; /* Define o posicionamento relativo para que possamos posicionar a foto de perfil */
    width: 40px; /* Define a largura */
    height: 40px; /* Define a altura */
    border-radius: 50%; /* Torna a foto redonda */
    overflow: hidden; /* Oculta qualquer conteúdo que exceda as dimensões do contêiner */
}

.foto-membro img {
    position: absolute; /* Define o posicionamento absoluto para a imagem */
    top: 0; /* Alinha a imagem no topo do contêiner */
    left: 0; /* Alinha a imagem à esquerda do contêiner */
    width: 100%; /* Define a largura da imagem como 100% do contêiner */
    height: 100%; /* Define a altura da imagem como 100% do contêiner */
    object-fit: cover; /* Faz com que a imagem preencha completamente o contêiner, mantendo a proporção */
    z-index: 1; /* Define a posição da imagem sobreposta a outros elementos */
}
</style>
    
</head>
<body>
    <div class="container py-5">
        <h1 class="mb-4">IEADAM</h1>
    </div>


<div class="container">
    <!-- Lista de membros -->
    <ul class="lista-membros">
        <?php
        // Conectar ao banco de dados e recuperar membros
        include('db/conexao.php');
        $sql = "SELECT * FROM usuarios";
        $result = mysqli_query($conexao, $sql);

        // Verificar se há membros cadastrados
        if (mysqli_num_rows($result) > 0) {
            // Loop através dos resultados e exibir cada membro
            while ($row = mysqli_fetch_assoc($result)) {
                echo '<li>
                        <div class="membro">
                            <div class="foto-membro">';
                // Verifica se a foto do perfil está definida
                if (!empty($row['foto'])) {
                    // Se estiver definida, exibe a foto
                    echo '<img src="uploads/' . $row['foto'] . '" alt="Foto de perfil">';
                } else {
                    // Se não estiver definida, exibe o ícone padrão de usuário
                    echo '<i class="fas fa-user"></i>';
                }
                echo '</div>
                            <div class="info-membro">
                                <span class="nome-membro">' . $row['nome'] . '<br></span>
                                <span class="funcao-membro">' . $row['funcao'] . '</span>
                                <br><span class="aniversario"><i class="fas fa-birthday-cake"></i> ' . date("d/m", strtotime($row['aniversario'])) . '</span>
                                <span class="acoes-membro">
                                    
                                </span>
                            </div>
                        </div>
                    </li>';
            }
        } else {
            echo "<li><p>Nenhum membro cadastrado.</p></li>";
        }

        // Fechar a conexão com o banco de dados
        mysqli_close($conexao);
        ?>
    </ul>
</div>
<script>
function apagarUsuario(idUsuario) {
    if (confirm("Tem certeza de que deseja apagar este usuário?")) {
        // Faz a requisição AJAX
        var xhr = new XMLHttpRequest();
        xhr.open("POST", "apagar_usuario.php", true);
        xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xhr.onreadystatechange = function () {
            if (xhr.readyState == 4 && xhr.status == 200) {
                // Atualiza a página após a exclusão do usuário
                window.location.reload();
            }
        };
        xhr.send("id=" + idUsuario);
    }
}
</script>
    <!-- Botão de adicionar usuário -->
    

    <!-- Modal de adicionar usuário -->
    <div class="modal fade" id="addUserModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Adicionar Usuário</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <!-- Formulário para adicionar usuário -->
<form action="adicionar_usuario.php" method="POST">
    <div class="mb-3">
        <label for="nome" class="form-label">Nome</label>
        <div class="input-group">
            <span class="input-group-text"><i class="fas fa-user"></i></span>
            <input type="text" class="form-control" id="nome" name="nome" required>
        </div>
    </div>
    <div class="mb-3">
        <label for="email" class="form-label">Email</label>
        <div class="input-group">
            <span class="input-group-text"><i class="fas fa-envelope"></i></span>
            <input type="email" class="form-control" id="email" name="email" required>
        </div>
    </div>
    <div class="mb-3">
        <label for="senha" class="form-label">Senha</label>
        <div class="input-group">
            <span class="input-group-text"><i class="fas fa-lock"></i></span>
            <input type="password" class="form-control" id="senha" name="senha" required>
        </div>
    </div>
    <div class="mb-3">
        <label for="funcao" class="form-label">Função</label>
        <div class="input-group">
            <span class="input-group-text"><i class="fas fa-church"></i></span>
            <select class="form-select" id="funcao" name="funcao" required>
                <option value="voz">Voz</option>
                <option value="Teclado">Teclado</option>
                <option value="Baixo">Baixo</option>
                <option value="Bateria">Bateria</option>
                <option value="Guitarra">Guitarra</option>
                <option value="Violão">Violão</option>
                <option value="Violino">Violino</option>
                <option value="Midia">Mídia</option>
            </select>
        </div>
    </div>
    <div class="mb-3">
        <label for="aniversario" class="form-label">Aniversário</label>
        <div class="input-group">
            <span class="input-group-text"><i class="fas fa-calendar-alt"></i></span>
            <input type="date" class="form-control" id="aniversario" name="aniversario" required>
        </div>
    </div>
    <button type="submit" class="btn btn-primary">Adicionar</button>
</form>
                </div>
            </div>
        </div>
    </div>
    <?php include('menu.php'); ?>
    <!-- JavaScript (opcional) -->
    <!-- Bootstrap Bundle com Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>