<?php
session_start();

// Verifica se a variável GET 'pag' está definida
if (isset($_GET['pag'])) {
    // Armazena o valor da variável GET 'pag' na sessão do usuário
    $_SESSION['pagina_destacada'] = $_GET['pag'];
}

// Define 'agenda' como padrão se a sessão não estiver definida
if (!isset($_SESSION['pagina_destacada'])) {
    $_SESSION['pagina_destacada'] = 'agenda';
}
?>
<nav class="footer-menu navbar navbar-light bg-light">
    <div class="container-fluid justify-content-around">
        <a class="nav-link <?php echo ($_SESSION['pagina_destacada'] === 'agenda') ? 'active' : ''; ?>" href="index.php?pag=agenda">
            <i class="far fa-calendar-alt"></i> Agenda
        </a>
        <a class="nav-link <?php echo ($_SESSION['pagina_destacada'] === 'membros') ? 'active' : ''; ?>" href="membros.php?pag=membros">
            <i class="fas fa-users"></i> Membros
        </a>
        <a class="nav-link <?php echo ($_SESSION['pagina_destacada'] === 'perfil') ? 'active' : ''; ?>" href="perfil.php?pag=perfil">
            <i class="fas fa-user"></i> Perfil
        </a>
    </div>
</nav>
