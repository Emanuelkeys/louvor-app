<?php
include('verify.php');
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LOUVOR</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome (ícones) -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <!-- CSS personalizado -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/musica.css" rel="stylesheet">
    <style>
        .add-music-button {
            position: fixed;
            bottom: 60px;
            right: 20px;
            width: 50px;
            height: 50px;
            background-color: #007bff;
            color: #fff;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.2);
        }

        .add-music-button:hover {
            background-color: #0056b3;
        }

        .music-details {
            display: none;
        }
        /* Estilo para o título e a data dos eventos */
.music-item .title,
.music-item .artist {
    text-decoration: none; /* Remove sublinhado */
}
.music-gallery {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 20px;
}

.music-item {
    background-color: #f8f9fa;
    padding: 20px;
    border-radius: 10px;
    text-decoration: none;
    color: #333; /* Cor do texto */
    transition: background-color 0.3s ease;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Sombra suave */
}

.music-item:hover {
    background-color: #e9ecef;
}

.music-item .far {
    font-size: 24px;
    margin-bottom: 10px;
    color: #007bff; /* Cor do ícone */
}

.music-item .title {
    font-weight: bold;
    margin-bottom: 5px;
}

.music-item .artist {
    font-style: italic;
    color: #6c757d; /* Cor do texto em itálico */
}
.container {
    max-height: 700px; /* Define a altura máxima do container */
    overflow-y: auto; /* Adiciona rolagem automática vertical */
}
    </style>
</head>
<body>
<div class="container py-5">
    <h1 class="mb-4">IEADAM</h1>
</div>
<div class="container">
    <div class="music-gallery">
        <?php
        include('db/conexao.php');
        $sql = "SELECT id, titulo, data_evento FROM eventos ORDER BY data_evento ASC";
        $resultado = mysqli_query($conexao, $sql);
        if (mysqli_num_rows($resultado) > 0) {
            while ($row = mysqli_fetch_assoc($resultado)) {
                // Adiciona um link com o ID do evento para a página detalhes_eventos.php
                echo "<a href='detalhes_eventos.php?evento_id=" . $row['id'] . "' class='music-item event-item'>";
                echo "<i class='far fa-calendar-alt'></i>";
                echo "<p class='title'>" . $row['titulo'] . "</p>";
                echo "<p class='artist'>" . date('d/m/Y', strtotime($row['data_evento'])) . "</p>";
                echo "</a>";
            }
        } else {
            echo "<div class='mensagem' style='background-color: #ff9999; color: #fff; padding: 20px; font-weight: bold; border-radius: 5px;'>Nenhuma agenda cadastrada</div>";
        }
        mysqli_close($conexao);
        ?>
    </div>
</div>

<!-- Seu código JavaScript aqui -->
<script>
    // Adiciona um evento de clique ao botão "Adicionar Nova Agenda"
    document.getElementById('addMusicButton').addEventListener('click', function() {
        // Seleciona o modal de adição de nova agenda
        var addAgendaModal = new bootstrap.Modal(document.getElementById('addAgendaModal'));
        // Exibe o modal
        addAgendaModal.show();
    });
</script>

<!-- Seu código para inclusão do menu aqui -->
<?php include('menu.php'); ?>

<!-- Seu código para inclusão das bibliotecas JavaScript aqui -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>