<?php
session_start();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LOUVOR - Membros</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome (ícones) -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <!-- CSS personalizado -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/membro.css" rel="stylesheet">
    <style>
    .add-user-button {
        position: fixed;
        bottom: 60px;
        right: 20px;
        z-index: 1000;
        border-radius: 50%; /* Torna o botão redondo */
        width: 50px; /* Define a largura */
        height: 50px; /* Define a altura */
        text-align: center; /* Alinha o ícone verticalmente */
        line-height: 40px; /* Centraliza o ícone horizontalmente */
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); /* Adiciona sombra ao botão */
    }
  .foto-membro {
    position: relative; /* Define o posicionamento relativo para que possamos posicionar a foto de perfil */
    width: 40px; /* Define a largura */
    height: 40px; /* Define a altura */
    border-radius: 50%; /* Torna a foto redonda */
    overflow: hidden; /* Oculta qualquer conteúdo que exceda as dimensões do contêiner */
}

.foto-membro img {
    position: absolute; /* Define o posicionamento absoluto para a imagem */
    top: 0; /* Alinha a imagem no topo do contêiner */
    left: 0; /* Alinha a imagem à esquerda do contêiner */
    width: 100%; /* Define a largura da imagem como 100% do contêiner */
    height: 100%; /* Define a altura da imagem como 100% do contêiner */
    object-fit: cover; /* Faz com que a imagem preencha completamente o contêiner, mantendo a proporção */
    z-index: 1; /* Define a posição da imagem sobreposta a outros elementos */
}
.container {
    position: relative;
    top: 20px; /* Move o contêiner para baixo */
    max-height: 470px;
    overflow-y: auto; /* Alterado para 'auto' para habilitar a rolagem quando necessário */
    max-width: 500px;
    margin-left: 10px;
    margin-right: auto;
}
</style>
    
</head>
<body>
    <div class="container py-5">
        <h1 class="mb-4">IEADAM</h1>
    </div>
    <?php include('menu.php'); ?>

<div class="container">
    <!-- Lista de membros -->
    <ul class="lista-membros">
        <?php
        // Conectar ao banco de dados e recuperar membros
        include('db/conexao.php');
        $sql = "SELECT * FROM usuarios";
        $result = mysqli_query($conexao, $sql);

        // Verificar se há membros cadastrados
        if (mysqli_num_rows($result) > 0) {
            // Loop através dos resultados e exibir cada membro
            while ($row = mysqli_fetch_assoc($result)) {
                echo '<li>
                        <div class="membro">
                            <div class="foto-membro">';
                // Exibir a foto do perfil
                if (!empty($row['foto'])) {
                    // Se estiver definida, exibe a foto
                    echo '<img src="uploads/' . $row['foto'] . '" alt="Foto do perfil">';
                } else {
                    // Se não estiver definida, exibe o ícone padrão de usuário
                    echo '<i class="far fa-user-circle fa-5x"></i>';
                }
                echo '</div>
                            <div class="info-membro">
                                <span class="nome-membro">' . $row['nome'] . '<br></span>
                                <span class="funcao-membro">' . $row['funcao'] . '</span>
                                <br><span class="aniversario"><i class="fas fa-birthday-cake"></i> ' . date("d/m", strtotime($row['aniversario'])) . '</span>
                            </div>
                        </div>
                    </li>';
            }
        } else {
            echo "<li><p>Nenhum membro cadastrado.</p></li>";
        }

        // Fechar a conexão com o banco de dados
        mysqli_close($conexao);
        ?>
    </ul>
</div>
<script>
function apagarUsuario(idUsuario) {
    if (confirm("Tem certeza de que deseja apagar este usuário?")) {
        // Faz a requisição AJAX
        var xhr = new XMLHttpRequest();
        xhr.open("POST", "apagar_usuario.php", true);
        xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xhr.onreadystatechange = function () {
            if (xhr.readyState == 4 && xhr.status == 200) {
                // Atualiza a página após a exclusão do usuário
                window.location.reload();
            }
        };
        xhr.send("id=" + idUsuario);
    }
}
</script>

    

    <!-- JavaScript (opcional) -->
    <!-- Bootstrap Bundle com Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>