<?php
session_start();

// Verifica se a variável de sessão 'email' está definida
if (!isset($_SESSION['email'])) {
    // Se não estiver definida, redireciona o usuário para a página de login
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LOUVOR</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome (ícones) -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <!-- CSS personalizado -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/musica.css" rel="stylesheet">
   <style>
        body {
            background-color: #f8f9fa;
            color: #343a40;
        }

        .container {
            max-width: 600px;
        }

        .container-title {
            margin-top: 30px;
            color: #007bff;
        }

        .evento-info {
            margin-bottom: 30px;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }

        .escala-info {
            margin-bottom: 50px;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }

        .btn-detalhes {
            margin-left: 10px;
        }

        .modal-header {
            background-color: #007bff;
            color: #fff;
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
            border-bottom: none;
            padding-top: 20px;
            padding-bottom: 20px;
        }

        .modal-title {
            font-size: 1.5rem;
            font-weight: bold;
            text-align: center;
            margin-bottom: 0;
        }

        .modal-body {
            padding: 20px;
            text-align: left;
        }

        .modal-footer {
            border-top: none;
        }

        .btn-close {
            color: #fff;
            opacity: 0.8;
            font-size: 1.5rem;
            padding: 0;
        }

        .btn-close:hover {
            opacity: 1;
        }

        .bi-person {
            font-size: 1.2rem;
            margin-right: 5px;
        }
        .container.main {
    margin-top: 150px; /* Espaçamento do conteúdo abaixo do container fixo */
    max-height: 500px; /* Altura máxima da div principal */
    overflow-y: auto; /* Adiciona rolagem vertical */
    max-width: 500px; /* Largura máxima desejada */
    margin-left: 10px; /* Centraliza horizontalmente */
    margin-right: auto; /* Centraliza horizontalmente */
}
    </style>
   <style>
        /* Estilo para o modal */
        .modal-dialog {
            max-width: 80%;
            margin: auto; /* Centralizar o modal */
        }

        .modal-content {
            border-radius: 10px;
        }

        .modal-header {
            border-bottom: none;
            padding-top: 20px;
            padding-bottom: 20px;
        }

        .modal-title {
            font-size: 1.5rem;
            font-weight: bold;
            text-align: center;
            margin-bottom: 0;
        }

        .modal-body {
            padding: 20px;
            text-align: left;
        }

        .modal-footer {
            border-top: none;
        }

        /* Estilo para os links das músicas */
        .music-link {
            display: block;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            background-color: #f2f2f2; /* Fundo dos links */
            padding: 5px 10px; /* Espaçamento interno */
            border-radius: 5px; /* Borda arredondada */
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.2); /* Sombra 3D */
            text-decoration: none; /* Remover sublinhado */
            color: #333; /* Cor do texto */
        }

        .highlight-person, .highlight-music {
            background-color: #f8f9fa; /* Cor de fundo clean */
            padding: 5px; /* Espaçamento interno para melhorar a aparência */
            border-radius: 5px; /* Arredondamento das bordas */
            color: #333; /* Cor do texto */
        }

        .highlight-person {
            font-weight: bold; /* Destacar o nome da pessoa */
        }

        .highlight-music {
            opacity: 0.7; /* Opacidade reduzida para o nome da música */
        }

        /* Estilo para alinhar o texto à esquerda */
        .name-container {
            display: flex;
            align-items: baseline; /* Alinha os elementos pela base */
        }

        .name-container span {
            margin-left: 10px; /* Margem à esquerda para separar os nomes */
        }

        /* Estilo para o botão de exclusão no canto inferior direito da tela */
        .btn-fixed-bottom-right {
            position: fixed;
            bottom: 80px;
            right: 20px;
            z-index: 999; /* Certifica-se de que o botão esteja acima de outros elementos */
        }
    </style> 
</head>

<body>
    <div class="container py-5">
        <h1 class="mb-4 container-title">IEADAM143</h1>
    </div>

    <!-- Botão de exclusão no canto inferior direito da tela -->
  
<div class="container">
    <?php
    // Se o parâmetro evento_id estiver definido na URL
    if (isset($_GET['evento_id'])) {
        // Conecta ao banco de dados
         $conexao = mysqli_connect("sql207.infinityfree.com", "if0_34827166", "IiELyoJJ8I0", "if0_34827166_145");
        // Verifica a conexão
        if (mysqli_connect_errno()) {
            echo "<div class='alert alert-danger' role='alert'>Erro ao conectar ao banco de dados: " . mysqli_connect_error() . "</div>";
            exit();
        }

        // Obtém o ID do evento da URL
        $evento_id = $_GET['evento_id'];

        // Consulta SQL para obter as informações do evento
        $sql_evento = "SELECT * FROM eventos WHERE id = $evento_id";
        $result_evento = mysqli_query($conexao, $sql_evento);

        // Verifica se o evento foi encontrado
            if (mysqli_num_rows($result_evento) > 0) {
                $evento = mysqli_fetch_assoc($result_evento);
                echo "<div class='evento-info text-center'>";
                echo "<h4>{$evento['titulo']}</h4>";
                echo "<div class='alert alert-warning text-center'<p><i class='fas fa-bell'></i> {$evento['descricao']}</p></div>";
            } else {
                echo "<div class='alert alert-danger' role='alert'>Evento não encontrado.</div>";
            }

        // Consulta SQL para obter as pessoas escaladas e as músicas que elas vão tocar
$sql_pessoas_musicas = "SELECT escala.id_escala, usuarios.nome AS nome_pessoa, musicas.titulo AS nome_musica, musicas.artista, musicas.link_musica, musicas.link_cifra, musicas.link_vs, usuarios.funcao
                        FROM escala
                        LEFT JOIN usuarios ON escala.nome_pessoa = usuarios.id
                        LEFT JOIN musicas ON escala.nome_musica = musicas.id
                        WHERE escala.id_evento = $evento_id
                        ORDER BY usuarios.funcao DESC"; // Ordenar por função para garantir que músicos apareçam antes de vocalistas
$result_pessoas_musicas = mysqli_query($conexao, $sql_pessoas_musicas);

// Verifica se a consulta SQL retornou resultados antes de tentar recuperá-los
if ($result_pessoas_musicas === false) {
    echo "<div class='alert alert-danger' role='alert'>Erro ao executar a consulta de pessoas e músicas escaladas: " . mysqli_error($conexao) . "</div>";
} elseif (mysqli_num_rows($result_pessoas_musicas) > 0) {
    echo "<div class='escala-info text-center'>";
    echo "<!--<h5 class='mb-3'>Escala:</h5>-->";
    echo "<ul class='list-group'>";
    $last_function = ""; // Guardar a última função para separar as escalas
    while ($row = mysqli_fetch_assoc($result_pessoas_musicas)) {
    if ($row['funcao'] != $last_function) {
        // Debugging: Exibir o valor de $row['funcao']
        echo "<br><p>Escala: " . $row['funcao'] . "</p>";

        echo "<!--<h5>" . ($row['funcao'] == "musico" ? "Escala de Músicos" : "Escala de Vocalistas") . "</h5>-->";
        $last_function = $row['funcao'];
    }
    // Restante do código...

    echo "<li class='list-group-item d-flex justify-content-between align-items-center'>";
    echo "<div class='name-container'>";
    echo "<span class='highlight-person'>{$row['nome_pessoa']}</span>";
    echo "<span class='highlight-music'>{$row['nome_musica']}</span>";
    echo "</div>";
    // Verifica se a função é "musico" e, se for, não exibe o botão "Ver"
    if ($row['funcao'] != "musico") {
        echo "<a href='#' class='btn btn-primary btn-detalhes' data-toggle='modal' data-target='#myModal{$row['id_escala']}' data-music-title='{$row['nome_musica']}'>Ver</a>";
    }
    echo "</li>";
}
    
    echo "</ul>";
    echo "</div>";

            // Cria o modal para cada música da escala
            mysqli_data_seek($result_pessoas_musicas, 0); // Volta o ponteiro do resultado para o início
            while ($row = mysqli_fetch_assoc($result_pessoas_musicas)) {
                echo "<div class='modal fade' id='myModal{$row['id_escala']}' tabindex='-1' aria-labelledby='musicDetailsModalLabel' aria-hidden='true'>";
                echo "<div class='modal-dialog modal-lg'>";
                echo "<div class='modal-content'>";
                echo "<div class='modal-header bg-primary text-white'>";
                echo "<h5 class='modal-title' id='musicDetailsModalLabel'><i class='fas fa-music'></i> Detalhes da Música</h5>";
                echo "<!--<button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='Close'></button>-->";
                echo "</div>";
                echo "<div class='modal-body'>";
                echo "<h4>{$row['nome_musica']}</h4>";
                echo "<p><strong>Artista:</strong> {$row['artista']}</p>";
                echo "<p><strong> Música:</strong> <a href='{$row['link_musica']}' target='_blank' class='music-link'><i class='fab fa-youtube'></i> {$row['link_musica']}</a></p>";
                echo "<p><strong>Cifra:</strong> <a href='{$row['link_cifra']}' target='_blank' class='music-link'><i class='fas fa-link'></i> {$row['link_cifra']}</a></p>";
                echo "<p><strong>VS:</strong> <a href='{$row['link_vs']}' target='_blank' class='music-link'><i class='fas fa-file'></i> {$row['link_vs']}</a></p>";
                echo "</div>";
                echo "<div class='modal-footer'>";
                echo "<!--<button type='button' class='btn btn-secondary' data-bs-dismiss='modal'>Fechar</button>-->";
                echo "</div>";
                echo "</div>";
                echo "</div>";
                echo "</div>";
            }
        } else {
            echo "<div class='alert alert-warning' role='alert'>Este evento não tem escala feita.</div>";
        }
    } else {
        // Retorna uma mensagem de erro se o parâmetro evento_id não foi passado
        echo "<div class='alert alert-danger' role='alert'>Erro: ID do evento não especificado.</div>";
    }
    // Fecha a conexão com o banco de dados
    mysqli_close($conexao);
    ?>
</div>
    <!-- Bootstrap JS e jQuery (opcional) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <script>
        $(document).ready(function () {
            $('.btn-detalhes').click(function () {
                // Obter informações da música associada ao botão
                var musicTitle = $(this).data('music-title');

                // Atualizar o conteúdo do modal com as informações da música
                $('#musicTitle').text(musicTitle);
            });

            // Adicione um ouvinte de evento para o clique no botão de exclusão
            $('#excluirEvento').click(function () {
                // Confirme se o usuário realmente deseja excluir o evento
                if (confirm('Tem certeza de que deseja excluir este evento?')) {
                    // Redirecionar para o script de exclusão do evento no banco de dados
                    window.location.href = 'excluir_evento.php?evento_id=<?php echo $evento_id; ?>';
                }
            });
        });
    </script>
    <?php include('menu.php'); ?>
</body>

</html>