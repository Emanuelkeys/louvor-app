<?php
session_start();

// Verifica se a variável de sessão 'email' está definida
if (!isset($_SESSION['email'])) {
    // Se não estiver definida, redireciona o usuário para a página de login
    header("Location: login.php");
    exit();
}

// Inclui o arquivo de conexão com o banco de dados
include('db/conexao.php');

// Recupera o email do usuário da sessão
$email = $_SESSION['email'];

// Consulta SQL para recuperar as informações do usuário com base no email
$sql = "SELECT * FROM usuarios WHERE email='$email'";
$result = mysqli_query($conexao, $sql);

// Verifica se a consulta foi bem-sucedida
if ($result) {
    // Verifica se encontrou algum usuário com o email fornecido
    if (mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_assoc($result); // Extrai os dados do usuário

        // Recupera as informações do usuário
        $nome = $row['nome'];
        $funcao = $row['funcao'];
        // Adicione mais informações conforme necessário
    } else {
        // Se não encontrou nenhum usuário, redireciona para o login
        header("Location: login.php");
        exit();
    }
} else {
    // Se houver algum erro na consulta, redireciona para uma página de erro
    header("Location: error.php");
    exit();
}

// Fecha a conexão com o banco de dados
mysqli_close($conexao);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil do Usuário</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- CSS personalizado -->
    <link href="css/perfil.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <!-- Font Awesome (ícones) -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
      .container {
    max-height: 700px; /* Define a altura máxima do container */
    overflow-y: auto; /* Adiciona rolagem automática vertical */
}
    </style>
</head>
<body>
    <div class="container py-5">
        <h1 class="mb-4">Perfil do Usuário</h1>
    </div>

    <!-- Exibir o menu -->
    <?php include('menu.php'); ?>

    <!-- Perfil do usuário -->
    <div class="container">
        <div class="perfil">
            <div class="foto-perfil">
    <!-- Exibir a foto do perfil -->
    <?php
    // Verifica se a foto do perfil está definida
    if (!empty($row['foto'])) {
        // Se estiver definida, exibe a foto
        echo '<img src="uploads/' . $row['foto'] . '" alt="Foto do perfil">';
    } else {
        // Se não estiver definida, exibe o ícone padrão de usuário
       echo '<i class="far fa-user-circle fa-5x"></i>';
    	}
    ?>
</div>
            <div class="informacoes-perfil">
                <!-- Exibir as informações do perfil -->
                <p><strong>Nome:</strong> <?php echo $nome; ?></p>
                <p><strong>Email:</strong> <?php echo $email; ?></p>
                <p><strong>Função:</strong> <?php echo $funcao; ?></p>
                <!-- Adicione mais informações conforme necessário -->
                
                <!-- Botão de editar -->
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#editarModal"><i class="fas fa-edit"></i> Editar Perfil</button>
                
                <a href="logout.php" class="btn btn-danger">Sair</a>
            </div>
        </div>
    </div>

    <!-- Modal de edição -->
<div class="modal fade" id="editarModal" tabindex="-1" aria-labelledby="editarModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editarModalLabel">Editar Perfil</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <!-- Formulário de edição -->
                <form action="editar_perfil.php" method="POST" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label for="novoNome" class="form-label">Novo Nome:</label>
                        <input type="text" class="form-control" id="novoNome" name="novoNome" value="<?php echo $nome; ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="novaSenha" class="form-label">Alterar Senha:</label>
                        <input type="text" class="form-control" id="novaSenha" name="novaSenha" value="<?php echo $row['senha']; ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="novaFoto" class="form-label">Nova Foto:</label>
                        <input type="file" class="form-control" id="novaFoto" name="novaFoto">
                    </div>
                    <div class="mb-3">
                        <label for="novaDataNascimento" class="form-label">atualizar Data de Nascimento:</label>
                        <input type="date" class="form-control" id="novaDataNascimento" name="novaDataNascimento" value="<?php echo $row['aniversario']; ?>" required>
                    </div>
                    <!-- Exibir foto de perfil atual -->
<div class="mb-3">
    <label></label><br>
    <?php
    // Verifica se a foto de perfil está definida
    if (!empty($row['foto'])) {
        // Se estiver definida, exibe a foto
        echo '<img src="uploads/' . $row['foto'] . '" alt="Foto do perfil" style="max-width: 100px;">';
    } else {
        // Se não estiver definida, exibe o ícone padrão de usuário
        echo '<i class="fas fa-user-circle fa-5x"></i>';
    }
    ?>
</div>
                    <button type="submit" class="btn btn-primary">Salvar Alterações</button>
                </form>
            </div>
        </div>
    </div>
</div>

    <!-- JavaScript (opcional) -->
    <!-- Bootstrap Bundle com Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>