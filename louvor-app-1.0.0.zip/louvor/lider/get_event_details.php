<?php
// Verifica se o parâmetro evento_id está definido na URL e se é um número válido
if (isset($_GET['evento_id']) && is_numeric($_GET['evento_id'])) {
    // Conecte-se ao banco de dados (substitua as credenciais conforme necessário)
    $conexao = mysqli_connect("sql207.infinityfree.com", "if0_34827166", "IiELyoJJ8I0", "if0_34827166_143");

    // Verifica a conexão
    if (!$conexao) {
        die("Erro ao conectar ao banco de dados: " . mysqli_connect_error());
    }

    // Obtém o ID do evento da URL
    $evento_id = $_GET['evento_id'];

    // Consulta SQL para excluir os registros da tabela de escala associados ao evento usando prepared statement
    $sql_excluir_escala = "DELETE FROM escala WHERE id_evento = ?";

    // Preparar a consulta
    $stmt_excluir_escala = mysqli_prepare($conexao, $sql_excluir_escala);

    // Verifica se a preparação da consulta foi bem-sucedida
    if ($stmt_excluir_escala) {
        // Vincular parâmetros e executar a consulta
        mysqli_stmt_bind_param($stmt_excluir_escala, "i", $evento_id);
        if (mysqli_stmt_execute($stmt_excluir_escala)) {
            // Consulta SQL para excluir o evento usando prepared statement
            $sql_excluir_evento = "DELETE FROM eventos WHERE id = ?";

            // Preparar a consulta
            $stmt_excluir_evento = mysqli_prepare($conexao, $sql_excluir_evento);

            // Verifica se a preparação da consulta foi bem-sucedida
            if ($stmt_excluir_evento) {
                // Vincular parâmetros e executar a consulta
                mysqli_stmt_bind_param($stmt_excluir_evento, "i", $evento_id);
                if (mysqli_stmt_execute($stmt_excluir_evento)) {
                    // Evento excluído com sucesso, redirecione de volta para a página inicial ou para onde desejar
                    header("Location: index.php");
                    exit();
                } else {
                    // Se houver algum erro ao excluir o evento
                    echo "Erro ao excluir o evento: " . mysqli_stmt_error($stmt_excluir_evento);
                }
            } else {
                echo "Erro ao preparar a consulta para excluir o evento: " . mysqli_error($conexao);
            }
        } else {
            // Se houver algum erro ao excluir os registros da tabela de escala
            echo "Erro ao excluir os registros da tabela de escala: " . mysqli_stmt_error($stmt_excluir_escala);
        }
    } else {
        echo "Erro ao preparar a consulta para excluir os registros da tabela de escala: " . mysqli_error($conexao);
    }

    // Fechar conexão com o banco de dados
    mysqli_close($conexao);
} else {
    // Se o parâmetro evento_id não estiver definido na URL ou não for um número válido
    echo "ID do evento inválido.";
}
?>