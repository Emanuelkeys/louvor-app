<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
include('db/conexao.php');


    $conn = new mysqli($hostname, $username, $password, $database); // Corrigido '$dbname' para '$database'

    if ($conn->connect_error) {
        die("Conexão falhou: " . $conn->connect_error);
    }



    $create_table_query = "CREATE TABLE IF NOT EXISTS escala (
                            id_escala INT(11) AUTO_INCREMENT PRIMARY KEY,
                            id_evento INT(11) NOT NULL,
                            nome_musica VARCHAR(255) NOT NULL,
                            nome_pessoa VARCHAR(255) NOT NULL,
                            FOREIGN KEY (id_evento) REFERENCES eventos(id)
                          )";
    if ($conn->query($create_table_query) === false) {
        die("Erro ao criar tabela: " . $conn->error);
    }

    $id_evento = $_POST['id_evento'];
    $musica = $_POST['musicas'];
    $pessoa = $_POST['nomes_pessoa'];

    $stmt = $conn->prepare("INSERT INTO escala (id_evento, nome_musica, nome_pessoa) VALUES (?, ?, ?)");

    if ($stmt === false) {
        die("Erro ao preparar a consulta: " . $conn->error);
    }

    if ($stmt->bind_param("iss", $id_evento, $musica, $pessoa) === false) {
        die("Erro ao vincular parâmetros: " . $stmt->error);
    }

    if ($stmt->execute() === false) {
        die("Erro ao inserir na tabela de escala: " . $stmt->error);
    }

    $conn->close();
    header("Location: escala.php");
    exit();
} else {
    header("Location: erro.php");
    exit();
}
?>