<?php
session_start();
include('db/conexao.php');
// Verifica se a variável de sessão 'email' está definida
if (!isset($_SESSION['email'])) {
    // Se não estiver definida, redireciona o usuário para a página de login
    header("Location: login.php");
    exit();
}

// Verifica o nível de permissão do usuário
$permissao = '';

// Aqui você deve ter alguma lógica para determinar o nível de permissão do usuário, por exemplo, consultando o banco de dados
// Suponha que você tenha uma tabela 'usuarios' com um campo 'funcao' que armazena a função do usuário (adm, lider, membro)
// Você pode consultar o banco de dados para obter a função do usuário com base no seu ID de usuário armazenado na sessão

// Exemplo de consulta ao banco de dados (substitua isso com sua lógica de consulta real)
$id_usuario = $_SESSION['id']; // Supondo que você armazene o ID do usuário na sessão
$query = "SELECT funcao FROM usuarios WHERE id = $id_usuario";
$resultado = mysqli_query($conexao, $query);

if ($resultado) {
    // Se a consulta for bem-sucedida
    $row = mysqli_fetch_assoc($resultado);
    $permissao = $row['funcao']; // Obtém a função do usuário
} else {
    // Se houver algum erro na consulta
    $permissao = 'membro'; // Define a permissão como membro por padrão
}

// Agora você pode usar a variável $permissao para determinar as permissões do usuário na sua aplicação
// Por exemplo:
if ($permissao === 'adm') {
    // O usuário é um administrador
} elseif ($permissao === 'lider') {
    // O usuário é um líder
} else {
    // O usuário é um membro
}
?>