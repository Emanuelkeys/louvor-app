<?php
// Verifique se o parâmetro evento_id está definido na URL e se é um número válido
if (isset($_GET['evento_id']) && is_numeric($_GET['evento_id'])) {
    // Conecte-se ao banco de dados (substitua as credenciais conforme necessário)
     $conexao = mysqli_connect("sql207.infinityfree.com", "if0_34827166", "IiELyoJJ8I0", "if0_34827166_145");

    // Verifica a conexão
    if (mysqli_connect_errno()) {
        echo "Erro ao conectar ao banco de dados: " . mysqli_connect_error();
        exit();
    }

    // Obtém o ID do evento da URL
    $evento_id = $_GET['evento_id'];

    // Consulta SQL para excluir os registros da tabela de escala associados ao evento
    $sql_excluir_escala = "DELETE FROM escala WHERE id_evento = $evento_id";

    // Executar a consulta SQL para excluir os registros da tabela de escala
    if (mysqli_query($conexao, $sql_excluir_escala)) {
        // Consulta SQL para excluir o evento
        $sql_excluir_evento = "DELETE FROM eventos WHERE id = $evento_id";

        // Executar a consulta SQL para excluir o evento
        if (mysqli_query($conexao, $sql_excluir_evento)) {
            // Evento excluído com sucesso, redirecione de volta para a página inicial ou para onde desejar
            header("Location: index.php");
            exit();
        } else {
            // Se houver algum erro ao excluir o evento
            echo "Erro ao excluir o evento: " . mysqli_error($conexao);
        }
    } else {
        // Se houver algum erro ao excluir os registros da tabela de escala
        echo "Erro ao excluir os registros da tabela de escala: " . mysqli_error($conexao);
    }

    // Fechar conexão com o banco de dados
    mysqli_close($conexao);
} else {
    // Se o parâmetro evento_id não estiver definido na URL ou não for um número válido
    echo "ID do evento inválido.";
}
?>