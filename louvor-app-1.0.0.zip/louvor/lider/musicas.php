<?php
session_start();

// Verifica se a variável de sessão 'email' está definida
if (!isset($_SESSION['email'])) {
    // Se não estiver definida, redireciona o usuário para a página de login
    header("Location: ../login.php");
    exit();
}

// Verifica se o ID da música a ser excluída foi enviado via GET
if (isset($_GET['delete_id'])) {
    // Conecta-se ao banco de dados
    include('db/conexao.php');

    // Obtém e sanitiza o ID da música a ser excluída
    $delete_id = mysqli_real_escape_string($conexao, $_GET['delete_id']);

    // Cria a consulta para excluir a música
    $sql = "DELETE FROM musicas WHERE id = $delete_id";

    // Executa a consulta
    if (mysqli_query($conexao, $sql)) {
        // Redireciona de volta para esta página após a exclusão
        header("Location: {$_SERVER['PHP_SELF']}");
        exit();
    } else {
        echo "Erro ao excluir música: " . mysqli_error($conexao);
    }

    // Fecha a conexão com o banco de dados
    mysqli_close($conexao);
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LOUVOR</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome (ícones) -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <!-- CSS personalizado -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/musica.css" rel="stylesheet">
    <style>
    
        .add-music-button {
            position: fixed;
            bottom: 60px;
            right: 20px;
            width: 50px;
            height: 50px;
            background-color: #007bff;
            color: #fff;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.2);
        }

        .add-music-button:hover {
            background-color: #0056b3;
        }

        .music-details {
            display: none;
        }
        
    </style>
    <!-- CONTAINER FIXO -->
   <style>
    .container.top-fixed {
        position: fixed;
        top: 0px; /* Ajuste a posição superior conforme desejado */
        left: 50%;
        transform: translateX(-50%);
        background-color: white; /* Cor de fundo desejada */
        padding: 5px; /* Espaçamento interno */
        border: 1px solid #ccc; /* Borda opcional */
        z-index: 999; /* Garante que esteja acima do outro container */
        text-align: center;
    }

.container.main{
    margin-top: 120px; /* Espaçamento do conteúdo abaixo do container fixo */
    max-height: 550px; /* Altura máxima da div principal */
    overflow-y: auto; /* Adiciona rolagem vertical */
    max-width: 500px; /* Largura máxima desejada */
    margin-left: 10px; /* Centraliza horizontalmente */
    margin-right: auto; /* Centraliza horizontalmente */
}

    .music-gallery {
        /* Adicione margem inferior para que haja espaço suficiente para a rolagem */
        margin-bottom: 20px;
    }

    .music-item {
        /* Adicione estilos para os itens da galeria de música conforme necessário */
    }
</style>
</head>

<body>
<div class="container top-fixed">
    <h1 class="mb-4">IEADAM</h1>
    <div class="input-group mb-3">
        <input type="text" class="form-control" id="searchInput" placeholder="Pesquisar música ou artista" aria-label="Pesquisar música ou artista" aria-describedby="button-addon2">
        <button class="btn btn-outline-secondary" type="button" id="button-addon2"><i class="fas fa-search"></i></button><br>
    </div>
</div>
<!-- Conteúdo específico da página de músicas -->
<div class="container main">
    <!-- Campo de pesquisa -->
    

    <!-- Galeria de músicas -->
    <div class="music-gallery">
        <!-- Aqui você pode iterar sobre as músicas e exibir cada uma delas como um item da galeria -->
        <?php
        // Incluir arquivo de conexão
        include('db/conexao.php');

        // Consulta SQL para selecionar as músicas
        $sql = "SELECT * FROM musicas";
        $resultado = mysqli_query($conexao, $sql);

        // Verifica se há músicas
        if (mysqli_num_rows($resultado) > 0) {
            // Loop através dos resultados
            while ($row = mysqli_fetch_assoc($resultado)) {
                echo "<div class='music-item' data-toggle='modal' data-target='#musicDetailsModal'";
                echo "data-title='" . $row['titulo'] . "' data-artist='" . $row['artista'] . "' data-link='" . $row['link_musica'] . "' data-cifra='" . $row['link_cifra'] . "' data-vs='" . $row['link_vs'] . "'>";
                echo "<i class='fas fa-music'></i>";
                echo "<p class='title'>" . $row['titulo'] . "</p>";
                echo "<p class='artist'>" . $row['artista'] . "</p>";
                echo "<a href='?delete_id=" . $row['id'] . "' class='btn btn-danger'>Excluir</a>";
                echo "</div>";
            }
        } else {
            echo "Nenhuma música Cadastrada";
        }

        // Fechar conexão com o banco de dados
        mysqli_close($conexao);
        ?>
    </div>
</div>

<!-- Modal de detalhes da música -->
<div class="modal fade" id="musicDetailsModal" tabindex="-1" aria-labelledby="musicDetailsModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div            class="modal-header">
                <h5 class="modal-title" id="musicDetailsModalLabel"><i class="fas fa-music"></i> Detalhes da Música</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <h4 id="musicTitle"></h4>
                <p id="musicArtist"><i class="fas fa-user"></i></p>
                <div class="row">
                    <div class="col">
                        <div id="musicLink"></div>
                    </div>
                    <div class="col">
                        <div id="musicCifra"></div>
                    </div>
                    <div class="col">
                        <div id="musicVS"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Botão para adicionar música -->
<div class="add-music-button" id="addMusicButton">
    <i class="fas fa-music"></i>
</div>

<!-- Modal de adição de música -->
<div class="modal fade" id="addMusicModal" tabindex="-1" aria-labelledby="addMusicModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addMusicModalLabel">Adicionar Música</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="addMusicForm">
                <!-- Formulário de adição de música -->
                <form action="musicas/cadastrar_musicas.php" method="post">
                    <div class="mb-3">
                        <label for="tituloInput" class="form-label visually-hidden">Título</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-music"></i></span>
                            <input type="text" class="form-control" id="tituloInput" name="titulo" placeholder="Título da música">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="artistaInput" class="form-label visually-hidden">Artista</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-user"></i></span>
                            <input type="text" class="form-control" id="artistaInput" name="artista" placeholder="Artista da música">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="linkMusicaInput" class="form-label visually-hidden">Link da música</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-music"></i></span>
                            <input type="text" class="form-control" id="linkMusicaInput" name="link_musica" placeholder="Link da música">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="linkCifraInput" class="form-label visually-hidden">Link da cifra</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="far fa-file-pdf"></i></span>
                            <input type="text" class="form-control" id="linkCifraInput" name="link_cifra" placeholder="Link da cifra">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="linkVSInput" class="form-label visually-hidden">Link do VS</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-headphones-alt"></i></span>
                            <input type="text" class="form-control" id="linkVSInput" name="link_vs" placeholder="Link do VS">
                        </div>
                    </div>
                    <!-- Adicione os outros campos conforme necessário -->
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                        <button type="submit" class="btn btn-primary">Salvar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    // Adiciona um evento de clique ao botão "Adicionar Música"
    document.getElementById('addMusicButton').addEventListener('click', function() {
        // Seleciona o modal de adição de música
        var addMusicModal = new bootstrap.Modal(document.getElementById('addMusicModal'));
        // Exibe o modal
        addMusicModal.show();
    });

    // Adiciona um evento de clique aos itens de música para exibir os detalhes
    var musicItems = document.querySelectorAll('.music-item');
    musicItems.forEach(function(item) {
        item.addEventListener('click', function() {
            var title = this.getAttribute('data-title');
            var artist = this.getAttribute('data-artist');
            var link = this.getAttribute('data-link');
            var cifra = this.getAttribute('data-cifra');
            var vs = this.getAttribute('data-vs');
            document.getElementById('musicTitle').textContent = title;
            document.getElementById('musicArtist').textContent = artist;
            document.getElementById('musicLink').innerHTML = "<a href='" + link + "' class='btn btn-primary'><i class='fas fa-music'></i> Link da música</a>";
            document.getElementById('musicCifra').innerHTML = "<a href='" + cifra + "' class='btn btn-primary'><i class='far fa-file-pdf'></i> Link da cifra</a>";
            document.getElementById('musicVS').innerHTML = "<a href='" + vs + "' class='btn btn-primary'><i class='fas fa-headphones-alt'></i> VS</a>";
            var musicDetailsModal = new bootstrap.Modal(document.getElementById('musicDetailsModal'));
            musicDetailsModal.show();
        });
    });

    // Adiciona funcionalidade de busca
    document.getElementById('button-addon2').addEventListener('click', function() {
        var searchTerm = document.getElementById('searchInput').value.toLowerCase();
        var musicItems = document.querySelectorAll('.music-item');
        musicItems.forEach(function(item) {
            var title = item.getAttribute('data-title').toLowerCase();
            var artist = item.getAttribute('data-artist').toLowerCase();
            if (title.includes(searchTerm) || artist.includes(searchTerm)) {
                item.style.display = 'block';
            } else {
                item.style.display = 'none';
            }
        });
    });
</script>
<?php include('menu.php'); ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>