<?php
session_start();

// Verifica se a variável de sessão 'email' não está definida
if (!isset($_SESSION['email'])) {
    // Se não estiver definida, redireciona o usuário para a página de login
    header("Location: ../login.php");
    exit();
}

// Configurações do banco de dados
$hostname = 'sql207.infinityfree.com'; // Endereço do servidor MySQL
$username = 'if0_34827166'; // Nome de usuário do banco de dados
$password = 'IiELyoJJ8I0'; // Senha do banco de dados
$database = 'if0_34827166_145'; // Nome do banco de dados

// Criar conexão
$conexao = mysqli_connect($hostname, $username, $password, $database);

// Verificar conexão
if (!$conexao) {
    die("Erro ao conectar ao banco de dados: " . mysqli_connect_error());
}

// Consulta SQL para verificar o nível de acesso do usuário
$email = $_SESSION['email'];

// Prepara e executa a consulta usando um prepared statement
$stmt = $conexao->prepare("SELECT nivel_acesso FROM usuarios WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->store_result();

// Verifica se a consulta retornou resultados
if ($stmt->num_rows > 0) {
    // Recupera o resultado da consulta
    $stmt->bind_result($nivel_acesso);
    $stmt->fetch();

    // Verifica se o usuário tem permissão de administrador
if ($nivel_acesso != 'adm') { 
        // Se não for um administrador, redireciona o usuário para a página de login
        header("Location: ../login.php");
        exit();
    }
} else {
    // Se o usuário não for encontrado no banco de dados, redireciona para o login
    header("Location: ../login.php");
    exit();
}

// Fecha a consulta
$stmt->close();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LOUVOR</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome (ícones) -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <!-- CSS personalizado -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/musica.css" rel="stylesheet">
    <style>
        .add-music-button {
            position: fixed;
            bottom: 60px;
            right: 20px;
            width: 50px;
            height: 50px;
            background-color: #007bff;
            color: #fff;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.2);
        }

        .add-music-button:hover {
            background-color: #0056b3;
        }

        .music-details {
            display: none;
        }
        /* Estilo para o título e a data dos eventos */
.music-item .title,
.music-item .artist {
    text-decoration: none; /* Remove sublinhado */
}
.music-gallery {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 20px;
}

.music-item {
    background-color: #f8f9fa;
    padding: 20px;
    border-radius: 10px;
    text-decoration: none;
    color: #333; /* Cor do texto */
    transition: background-color 0.3s ease;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Sombra suave */
}

.music-item:hover {
    background-color: #e9ecef;
}

.music-item .far {
    font-size: 24px;
    margin-bottom: 10px;
    color: #007bff; /* Cor do ícone */
}

.music-item .title {
    font-weight: bold;
    margin-bottom: 5px;
}

.music-item .artist {
    font-style: italic;
    color: #6c757d; /* Cor do texto em itálico */
}
.container.main {
    margin-top: 150px; /* Espaçamento do conteúdo abaixo do container fixo */
    max-height: 500px; /* Altura máxima da div principal */
    overflow-y: auto; /* Adiciona rolagem vertical */
    max-width: 500px; /* Largura máxima desejada */
    margin-left: 10px; /* Centraliza horizontalmente */
    margin-right: auto; /* Centraliza horizontalmente */
}
    </style>
</head>
<body>
<div class="container py-5">
    <h1 class="mb-4">IEADAM</h1>
    <?php include('menu.php'); ?>
</div>
<div class="container">
    <div class="music-gallery">
        <?php
        include('db/conexao.php');
        $sql = "SELECT id, titulo, data_evento FROM eventos ORDER BY data_evento ASC";
        $resultado = mysqli_query($conexao, $sql);
        if (mysqli_num_rows($resultado) > 0) {
            while ($row = mysqli_fetch_assoc($resultado)) {
                // Adiciona um link com o ID do evento para a página detalhes_eventos.php
                echo "<a href='detalhes_eventos.php?evento_id=" . $row['id'] . "' class='music-item event-item'>";
                echo "<i class='far fa-calendar-alt'></i>";
                echo "<p class='title'>" . $row['titulo'] . "</p>";
                echo "<p class='artist'>" . date('d/m/Y', strtotime($row['data_evento'])) . "</p>";
                echo "</a>";
            }
        } else {
            echo "<div class='mensagem' style='background-color: #ff9999; color: #fff; padding: 20px; font-weight: bold; border-radius: 5px;'>Nenhuma agenda cadastrada</div>";
        }
        mysqli_close($conexao);
        ?>
    </div>
</div>
<!-- Botão para adicionar nova agenda -->
<div class="add-music-button" id="addMusicButton">
    <i class="fas fa-calendar-plus"></i> <!-- Ícone para adicionar agenda -->
</div>

<!-- Modal para adicionar nova agenda -->
<div class="modal fade" id="addAgendaModal" tabindex="-1" aria-labelledby="addAgendaModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addAgendaModalLabel">Adicionar Nova Agenda</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form method="post" action="eventos/cadastrar_evento.php">
                    <div class="mb-3">
                        <label for="titulo" class="form-label">Título</label>
                        <input type="text" class="form-control" id="titulo" name="titulo" required>
                    </div>
                    <div class="mb-3">
    <label for="descricao" class="form-label">Descrição</label>
    <textarea class="form-control" id="descricao" name="descricao" rows="3" placeholder="Coloque aqui o Local do Ensaio e Hora."></textarea>
</div>
                    <div class="mb-3">
                        <label for="data" class="form-label">Data</label>
                        <input type="date" class="form-control" id="data" name="data" required>
                    </div>
                    <div class="mb-3">
                        <label for="hora" class="form-label">Hora</label>
                        <input type="time" class="form-control" id="hora" name="hora" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Adicionar</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Seu código JavaScript aqui -->
<script>
    // Adiciona um evento de clique ao botão "Adicionar Nova Agenda"
    document.getElementById('addMusicButton').addEventListener('click', function() {
        // Seleciona o modal de adição de nova agenda
        var addAgendaModal = new bootstrap.Modal(document.getElementById('addAgendaModal'));
        // Exibe o modal
        addAgendaModal.show();
    });
</script>

<!-- Seu código para inclusão das bibliotecas JavaScript aqui -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>