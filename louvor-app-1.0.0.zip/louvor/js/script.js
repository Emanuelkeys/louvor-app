// Função para mostrar o formulário de cadastro de eventos
function mostrarFormulario() {
    document.getElementById("cadastroEventoContainer").style.display = "block";
}

// Função para fechar o formulário de cadastro de eventos
function fecharFormulario() {
    document.getElementById("cadastroEventoContainer").style.display = "none";
}

// Event listener para fechar o formulário ao clicar fora dele
window.onclick = function(event) {
    if (event.target == document.getElementById("cadastroEventoContainer")) {
        document.getElementById("cadastroEventoContainer").style.display = "none";
    }
};

<!-- JavaScript para fazer a busca automática -->

    document.getElementById("searchInput").addEventListener("input", function() {
        var searchText = this.value.toLowerCase();
        var musicItems = document.querySelectorAll(".music-item");

        musicItems.forEach(function(item) {
            var title = item.querySelector(".title").textContent.toLowerCase();
            var artist = item.querySelector(".artist").textContent.toLowerCase();

            if (title.includes(searchText) || artist.includes(searchText)) {
                item.style.display = "block";
            } else {
                item.style.display = "none";
            }
        });
    });

    // Mostrar todas as músicas quando o campo de pesquisa está vazio
    document.getElementById("searchInput").addEventListener("input", function() {
        var searchText = this.value.toLowerCase();
        var musicItems = document.querySelectorAll(".music-item");

        if (searchText === "") {
            musicItems.forEach(function(item) {
                item.style.display = "block";
            });
        }
    });

