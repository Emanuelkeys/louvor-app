<?php
// Configurações do banco de dados
$hostname = 'sql207.infinityfree.com'; // Endereço do servidor MySQL
$username = 'if0_34827166'; // Nome de usuário do banco de dados
$password = 'IiELyoJJ8I0'; // Senha do banco de dados
$database = 'if0_34827166_145'; // Nome do banco de dados

// Criar conexão
$conexao = mysqli_connect($hostname, $username, $password, $database);

// Verificar conexão
if (!$conexao) {
    die("Erro ao conectar ao banco de dados: " . mysqli_connect_error());
}
?>