-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Tempo de geração: 18-Mar-2024 às 23:29
-- Versão do servidor: 10.4.6-MariaDB
-- versão do PHP: 7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `louvor`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `escala`
--

CREATE TABLE `escala` (
  `id_escala` int(11) NOT NULL,
  `nome_musica` varchar(255) NOT NULL,
  `nome_evento` varchar(255) NOT NULL DEFAULT 'Nome Padrão',
  `nome_pessoa` varchar(255) NOT NULL,
  `id_evento` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `escala`
--

INSERT INTO `escala` (`id_escala`, `nome_musica`, `nome_evento`, `nome_pessoa`, `id_evento`) VALUES
(64, '4', 'Nome Padrão', '5', 20),
(65, '8', 'Nome Padrão', '1', 20);

-- --------------------------------------------------------

--
-- Estrutura da tabela `eventos`
--

CREATE TABLE `eventos` (
  `id` int(11) NOT NULL,
  `titulo` varchar(255) NOT NULL,
  `descricao` text DEFAULT NULL,
  `data_evento` date DEFAULT NULL,
  `hora` time DEFAULT NULL,
  `id_usuario` int(11) DEFAULT NULL,
  `data_criacao` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `eventos`
--

INSERT INTO `eventos` (`id`, `titulo`, `descricao`, `data_evento`, `hora`, `id_usuario`, `data_criacao`) VALUES
(20, 'Prayer Worship ', 'Teste', '2024-03-18', '17:10:00', NULL, '2024-03-18 21:10:57'),
(21, 'Prayer Worship Tuor', 'Eeeeeeeeee isssso', '2024-03-31', '06:08:00', NULL, '2024-03-18 23:08:43');

-- --------------------------------------------------------

--
-- Estrutura da tabela `musicas`
--

CREATE TABLE `musicas` (
  `id` int(11) NOT NULL,
  `titulo` varchar(255) NOT NULL,
  `artista` varchar(255) DEFAULT NULL,
  `link_musica` varchar(255) DEFAULT NULL,
  `link_cifra` varchar(255) DEFAULT NULL,
  `link_vs` varchar(255) DEFAULT NULL,
  `evento_id` int(11) DEFAULT NULL,
  `id_usuario` int(11) DEFAULT NULL,
  `data_criacao` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `musicas`
--

INSERT INTO `musicas` (`id`, `titulo`, `artista`, `link_musica`, `link_cifra`, `link_vs`, `evento_id`, `id_usuario`, `data_criacao`) VALUES
(3, 'Barulho de festa ', 'Israel Salazar ', 'https://www.google.com/url?sa=t&source=web&rct=j&opi=89978449&url=https://m.youtube.com/watch%3Fv%3Dvo4CP9HDGkk&ved=2ahUKEwiFmO7N4feEAxUYDrkGHcG8D0MQo7QBegQICxAG&usg=AOvVaw0TZvrQu3uoF0_w7NRzpC5H', 'https://www.cifraclub.com.br/israel-salazar/barulho-de-festa/', '', NULL, NULL, '2024-03-17 18:28:48'),
(4, 'No Meio Dos Louvores', 'Israel Salazar ', 'https://www.google.com/url?sa=t&source=web&rct=j&opi=89978449&url=https://m.youtube.com/watch%3Fv%3Dvo4CP9HDGkk&ved=2ahUKEwiFmO7N4feEAxUYDrkGHcG8D0MQo7QBegQICxAG&usg=AOvVaw0TZvrQu3uoF0_w7NRzpC5H', 'https://www.cifraclub.com.br/israel-salazar/barulho-de-festa/', '', NULL, NULL, '2024-03-17 20:11:27'),
(5, 'TECLADO', 'Instrumento', '', '', '', NULL, NULL, '2024-03-18 02:41:33'),
(6, 'BATERIA', 'Instrumento', '', '', '', NULL, NULL, '2024-03-18 02:41:46'),
(7, 'BAIXO', 'Instrumento', '', '', '', NULL, NULL, '2024-03-18 02:42:01'),
(8, 'GUITARRA', 'Instrumento', '', '', '', NULL, NULL, '2024-03-18 02:42:19');

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `senha` varchar(255) DEFAULT NULL,
  `funcao` varchar(255) DEFAULT NULL,
  `foto` varchar(255) DEFAULT NULL,
  `aniversario` date DEFAULT NULL,
  `nivel_acesso` enum('adm','lider','membro') DEFAULT 'membro',
  `data_cadastro` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `nome`, `email`, `senha`, `funcao`, `foto`, `aniversario`, `nivel_acesso`, `data_cadastro`) VALUES
(1, 'Emanuel', 'Clashemanuel2002@gmail.com', '8814', 'Musico', 'emanuelkeys.png', '2002-08-22', 'adm', '2024-03-16 11:29:08'),
(5, 'Emanuel Silva', 'Isahribeiro789@gmail.com', '8814', 'voz', 'emanuelkeys.png', '2004-04-10', 'membro', '2024-03-18 18:44:36');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `escala`
--
ALTER TABLE `escala`
  ADD PRIMARY KEY (`id_escala`),
  ADD KEY `fk_id_evento` (`id_evento`);

--
-- Índices para tabela `eventos`
--
ALTER TABLE `eventos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_usuario` (`id_usuario`);

--
-- Índices para tabela `musicas`
--
ALTER TABLE `musicas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `evento_id` (`evento_id`),
  ADD KEY `id_usuario` (`id_usuario`);

--
-- Índices para tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `escala`
--
ALTER TABLE `escala`
  MODIFY `id_escala` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- AUTO_INCREMENT de tabela `eventos`
--
ALTER TABLE `eventos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT de tabela `musicas`
--
ALTER TABLE `musicas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `escala`
--
ALTER TABLE `escala`
  ADD CONSTRAINT `fk_id_evento` FOREIGN KEY (`id_evento`) REFERENCES `eventos` (`id`);

--
-- Limitadores para a tabela `eventos`
--
ALTER TABLE `eventos`
  ADD CONSTRAINT `eventos_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`);

--
-- Limitadores para a tabela `musicas`
--
ALTER TABLE `musicas`
  ADD CONSTRAINT `musicas_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`),
  ADD CONSTRAINT `musicas_ibfk_2` FOREIGN KEY (`evento_id`) REFERENCES `eventos` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
