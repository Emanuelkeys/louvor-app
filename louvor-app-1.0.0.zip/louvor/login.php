<?php
session_start();

// Configurações do banco de dados
$hostname = 'sql207.infinityfree.com'; // Endereço do servidor MySQL
$username = 'if0_34827166'; // Nome de usuário do banco de dados
$password = 'IiELyoJJ8I0'; // Senha do banco de dados
$database = 'if0_34827166_145'; // Nome do banco de dados

// Criar conexão
$conexao = mysqli_connect($hostname, $username, $password, $database);

// Verificar conexão
if (!$conexao) {
    die("Erro ao conectar ao banco de dados: " . mysqli_connect_error());
}

// Processamento do formulário de login
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['login'])) {
    $email = $_POST['email'];
    $senha = $_POST['senha'];

    $sql = "SELECT * FROM usuarios WHERE email='$email' AND senha='$senha'";
    $result = mysqli_query($conexao, $sql);

    if (mysqli_num_rows($result) == 1) {
        // Login bem-sucedido
        $row = mysqli_fetch_assoc($result);
        $_SESSION['email'] = $email;
        
        // Verifica se a opção de lembrar a senha está marcada
        if (isset($_POST['lembrar_senha'])) {
            // Define um cookie para lembrar a senha
            setcookie('lembrar_senha', 'true', time() + (86400 * 30), "/"); // 30 dias
        }
        
        // Verifica o nível de acesso do usuário
        $nivel_acesso = $row['nivel_acesso'];
        
        // Redireciona com base no nível de acesso
        if ($nivel_acesso === 'adm') {
            header("Location: lider/index.php");
            exit();
        } else {
            header("Location: index.php");
            exit();
        }
    } else {
        // Login falhou
        $login_error = "Email ou senha incorretos!";
    }
}

// Fecha a conexão com o banco de dados
mysqli_close($conexao);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>IEADAM143</title>
  <link rel="stylesheet" href="./style.css">
</head>
<body>
<!-- partial:index.partial.html -->
<div class="wrapper fadeInDown">
  <div id="formContent">
    <!-- Tabs Titles -->
    <h2 class="active"> Entrar </h2>

    <!-- Icon -->
    <div class="fadeIn first">
      <img src="img/ieadam145.png" id="icon" alt="User Icon" />
    </div>

    <!-- Login Form -->
    <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
      <input type="text" id="login" class="fadeIn second" name="email" placeholder="E-mail">
      <div class="password-container">
        <input type="password" id="password" class="fadeIn third" name="senha" placeholder="Senha">
        <span toggle="#password" class="fa fa-fw fa-eye field-icon toggle-password"></span>
      </div>
      <input type="checkbox" name="lembrar_senha" value="lembrar"> Lembrar senha<br>
      <input type="submit" class="fadeIn fourth" name="login" value="Entrar">
    </form>

    <!-- Exibir mensagem de erro de login, se houver -->
    <?php if (isset($login_error)): ?>
        <div class="error"><?php echo $login_error; ?></div>
    <?php endif; ?>

    <!-- Remind Passowrd -->
    <div id="formFooter">
      <!--<a class="underlineHover" href="#">Esqueceu a Senha?</a>-->
    </div>

  </div>
</div>
<!-- partial -->
  
</body>
</html>