<?php
session_start();
include('db/conexao.php');

// Processamento do formulário de cadastro
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['cadastrar'])) {
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $senha = $_POST['senha'];

    // Inserir o novo usuário no banco de dados e definir o nível de acesso como "lider"
    $sql = "INSERT INTO usuarios (nome, email, senha, nivel_acesso) VALUES ('$nome', '$email', '$senha', 'membro')";
    if (mysqli_query($conexao, $sql)) {
        // Cadastro bem-sucedido
        header("Location: index.php");
        exit();
    } else {
        // Erro ao cadastrar
        $cadastro_error = "Erro ao cadastrar o usuário. Por favor, tente novamente. Erro: " . mysqli_error($conexao);
    }
}

// Fecha a conexão com o banco de dados
mysqli_close($conexao);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>IEADAM143</title>
  <link rel="stylesheet" href="./style.css">
</head>
<body>
<!-- partial:index.partial.html -->
<div class="wrapper fadeInDown">
  <div id="formContent">
    <!-- Tabs Titles -->
    <h2 class="active"> Cadastro </h2>

    <!-- Icon -->
    <div class="fadeIn first">
      <img src="img/ieadam145.png" id="icon" alt="User Icon" />
    </div>

    <!-- Formulário de Cadastro -->
    <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
      <input type="text" id="nome" class="fadeIn second" name="nome" placeholder="Nome">
      <input type="text" id="email" class="fadeIn third" name="email" placeholder="E-mail">
      <div class="password-container">
        <input type="password" id="senha" class="fadeIn fourth" name="senha" placeholder="Senha">
        <span toggle="#senha" class="fa fa-fw fa-eye field-icon toggle-password"></span>
      </div>
      <input type="submit" class="fadeIn fifth" name="cadastrar" value="Cadastrar">
    </form>

    <!-- Exibir mensagem de erro de cadastro, se houver -->
    <?php if (isset($cadastro_error)): ?>
        <div class="error"><?php echo $cadastro_error; ?></div>
    <?php endif; ?>

  </div>
</div>
<!-- partial -->
  
</body>
</html>