<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Conexão com o banco de dados
$hostname = 'sql207.infinityfree.com';
$username = 'if0_34827166';
$password = 'IiELyoJJ8I0'; 
$database = 'if0_34827166_louvor'; 

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Conexão falhou: " . $conn->connect_error);
    }

    // Preparação e execução da consulta SQL para inserir os dados no banco de dados
    $stmt = $conn->prepare("INSERT INTO eventos (titulo, descricao, data_evento, hora) VALUES (?, ?, ?, ?)");

    if ($stmt === false) {
        die("Erro ao preparar a consulta: " . $conn->error);
    }

    // Associação de parâmetros e execução da consulta
    $titulo = $_POST['titulo'];
    $descricao = $_POST['descricao'];
    $data = $_POST['data'];
    $hora = $_POST['hora'];

    if ($stmt->bind_param("ssss", $titulo, $descricao, $data, $hora) === false) {
        die("Erro ao vincular parâmetros: " . $stmt->error);
    }

    if ($stmt->execute() === false) {
        die("Erro ao inserir no banco de dados: " . $stmt->error);
    }

    // Fechamento da conexão com o banco de dados
    $stmt->close();
    $conn->close();

    // Redirecionamento após a inserção bem-sucedida
    header("Location: ../index.php");
    exit();
} else {
    // Redirecionamento em caso de tentativa de acesso direto ao script
    header("Location: erro.php");
    exit();
}
?>