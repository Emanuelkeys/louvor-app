<?php
// Verifica se o formulário foi submetido
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Inclui o arquivo de conexão com o banco de dados
    include('db/conexao.php');

    // Obtém os dados do formulário
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $senha = $_POST['senha'];
    $funcao = $_POST['funcao'];
    $aniversario = $_POST['aniversario'];

    // Prepara a consulta SQL para inserir um novo usuário
    $sql = "INSERT INTO usuarios (nome, email, senha, funcao, aniversario) VALUES (?, ?, ?, ?, ?)";

    // Prepara a instrução SQL usando o método prepare
    $stmt = mysqli_prepare($conexao, $sql);

    // Verifica se a preparação da consulta foi bem-sucedida
    if ($stmt) {
        // Associa os parâmetros à instrução SQL
        mysqli_stmt_bind_param($stmt, "sssss", $nome, $email, $senha, $funcao, $aniversario);

        // Executa a consulta
        if (mysqli_stmt_execute($stmt)) {
            // Redireciona de volta para a página anterior após a inserção bem-sucedida
            header("Location: {$_SERVER['HTTP_REFERER']}");
            exit();
        } else {
            // Em caso de falha na execução da consulta
            echo "Erro ao adicionar usuário: " . mysqli_error($conexao);
        }

        // Fecha a instrução
        mysqli_stmt_close($stmt);
    } else {
        // Em caso de falha na preparação da consulta
        echo "Erro na preparação da consulta: " . mysqli_error($conexao);
    }

    // Fecha a conexão com o banco de dados
    mysqli_close($conexao);
} else {
    // Se o método de requisição HTTP não for POST, redireciona para a página anterior
    header("Location: {$_SERVER['HTTP_REFERER']}");
    exit();
}
?>