<?php
session_start();

// Verifica se o usuário está logado
if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}

// Inclui o arquivo de conexão com o banco de dados
include('db/conexao.php');

// Recebe os dados do formulário
$novoNome = $_POST['novoNome'];
$novaSenha = $_POST['novaSenha'];

// Verifica se uma nova foto foi enviada
if ($_FILES['novaFoto']['name']) {
    $novaFoto = $_FILES['novaFoto']['name'];
    $tempName = $_FILES['novaFoto']['tmp_name'];
    $fotoDir = "../uploads/"; // Diretório para salvar as fotos

    // Verifica se o diretório de uploads existe e cria se não existir
    if (!file_exists($fotoDir)) {
        mkdir($fotoDir, 0777, true);
    }

    $targetFile = $fotoDir . basename($novaFoto);

    // Move a foto para o diretório de uploads
    if (move_uploaded_file($tempName, $targetFile)) {
        // Foto movida com sucesso
    } else {
        // Se houver um erro ao mover a foto, exibe uma mensagem de erro
        echo "Erro ao mover a foto.";
        exit();
    }
} else {
    // Se nenhuma nova foto foi enviada, mantém a foto atual
    $novaFoto = $row['foto']; // Supondo que $row seja o resultado da consulta ao banco de dados
}

// Recupera o email do usuário da sessão
$email = $_SESSION['email'];

// Atualiza as informações do usuário no banco de dados
$sql = "UPDATE usuarios SET nome = '$novoNome', senha = '$novaSenha', foto = '$novaFoto' WHERE email = '$email'";
$result = mysqli_query($conexao, $sql);

// Verifica se a atualização foi bem-sucedida
if ($result) {
    // Redireciona de volta para a página do perfil com uma mensagem de sucesso
    header("Location: perfil.php?success=1");
    exit();
} else {
    // Se houver um erro na atualização, redireciona com uma mensagem de erro
    header("Location: perfil.php?error=1");
    exit();
}

// Fecha a conexão com o banco de dados
mysqli_close($conexao);
?>